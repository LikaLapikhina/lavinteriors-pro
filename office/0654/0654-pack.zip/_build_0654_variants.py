import urllib.request, json, sys
sys.stdout.reconfigure(encoding='utf-8')

def ac_post(cmd, params=None):
    req = urllib.request.Request(
        'http://127.0.0.1:19724',
        data=json.dumps({'command': cmd, 'parameters': params or {}}).encode('utf-8'),
        headers={'Content-Type': 'application/json'}
    )
    return json.loads(urllib.request.urlopen(req, timeout=30).read().decode('utf-8'))

def tapir(cmd, params=None):
    res = ac_post('API.ExecuteAddOnCommand', {
        'addOnCommandId': {'commandNamespace': 'TapirCommand', 'commandName': cmd},
        'addOnCommandParameters': params or {}
    })
    return res

# Base coordinates of Krivtsovo (Variant 1 is at dy=0.0, Variant 2 is at dy=+10.0)
X_LEFT = 86.985596279
X_RIGHT = 96.065596279
Y_BOT = -46.804376912
Y_TOP = -42.304376912

def build_variant(dy, is_second_copy=False):
    created_walls = []
    # 1. If is_second_copy (Variant 2 at Y + 10m), create outer walls & entry niche on layer 3 (01_01 Стены несущие)
    if is_second_copy:
        outer_walls_data = [
            # Bottom outer wall (СТН-011)
            {'begCoordinate': {'x': X_LEFT, 'y': Y_BOT + dy}, 'endCoordinate': {'x': X_RIGHT, 'y': Y_BOT + dy}, 'height': 2.64, 'thickness': 0.50},
            # Right outer wall (СТН-012)
            {'begCoordinate': {'x': X_RIGHT, 'y': Y_BOT + dy}, 'endCoordinate': {'x': X_RIGHT, 'y': Y_TOP + dy}, 'height': 2.64, 'thickness': 0.50},
            # Top outer wall (СТН-013)
            {'begCoordinate': {'x': X_RIGHT, 'y': Y_TOP + dy}, 'endCoordinate': {'x': X_LEFT, 'y': Y_TOP + dy}, 'height': 2.64, 'thickness': 0.50},
            # Left outer wall (СТН-014)
            {'begCoordinate': {'x': X_LEFT, 'y': Y_TOP + dy}, 'endCoordinate': {'x': X_LEFT, 'y': Y_BOT + dy}, 'height': 2.64, 'thickness': 0.50},
            # Entry closet horizontal partition (СТН-015)
            {'begCoordinate': {'x': X_LEFT, 'y': -44.954376912 + dy}, 'endCoordinate': {'x': 88.885596279, 'y': -44.954376912 + dy}, 'height': 2.64, 'thickness': 0.10},
            # Entry vestibule vertical partition (СТН-016)
            {'begCoordinate': {'x': 88.885596279, 'y': -44.954376912 + dy}, 'endCoordinate': {'x': 88.885596279, 'y': Y_BOT + dy}, 'height': 2.64, 'thickness': 0.10},
        ]
        rw = tapir('CreateWalls', {'wallsData': outer_walls_data})
        ow_list = rw.get('result', {}).get('addOnCommandResponse', {}).get('walls', [])
        print(f"[dy={dy}] Created {len(ow_list)} outer walls")
        if len(ow_list) == 6:
            # Set layerIndex = 3 (01_01 Стены несущие)
            tapir('SetDetailsOfElements', {
                'elementsWithDetails': [{'elementId': w['elementId'], 'layerIndex': 3} for w in ow_list]
            })
            # Add windows on Right wall (ow_list[1]) and Left wall (ow_list[3])
            tapir('CreateWindows', {
                'windowsData': [
                    {'ownerWallId': ow_list[1]['elementId'], 'centerOffset': 2.235, 'width': 2.81, 'height': 2.08, 'sillHeight': 0.19, 'reflected': True, 'refSide': True, 'oSide': True},
                    {'ownerWallId': ow_list[3]['elementId'], 'centerOffset': 1.51, 'width': 1.78, 'height': 1.91, 'sillHeight': 0.58, 'reflected': True, 'refSide': True, 'oSide': False}
                ]
            })
            # Add entry door on Left wall (ow_list[3]) and vestibule opening on СТН-016 (ow_list[5])
            tapir('CreateDoors', {
                'doorsData': [
                    {'ownerWallId': ow_list[3]['elementId'], 'centerOffset': 3.895, 'width': 0.99, 'height': 2.11, 'sillHeight': 0.13, 'reflected': True, 'refSide': True, 'oSide': False},
                    {'ownerWallId': ow_list[5]['elementId'], 'centerOffset': 1.295, 'width': 0.91, 'height': 2.30, 'sillHeight': 0.0, 'reflected': True, 'refSide': True, 'oSide': False}
                ]
            })
        # Also create communication columns on layer 4 (01_02 Коммуникации)
        rc = tapir('CreateColumns', {
            'columnsData': [
                {'coordinates': {'x': 93.290596279, 'y': -42.509376912 + dy, 'z': 0.0}},
                {'coordinates': {'x': 93.460727412, 'y': -42.588286466 + dy, 'z': 0.0}},
                {'coordinates': {'x': 91.602684295, 'y': -44.021767609 + dy, 'z': 0.0}},
                {'coordinates': {'x': 90.693313500, 'y': -45.442575798 + dy, 'z': 0.0}}
            ]
        })
        cols = rc.get('result', {}).get('addOnCommandResponse', {}).get('columns', [])
        if cols:
            tapir('SetDetailsOfElements', {
                'elementsWithDetails': [{'elementId': c['elementId'], 'layerIndex': 4} for c in cols]
            })

    # 2. Create NEW REDESIGNED PARTITIONS on layer 8 (02_01 Новые перегородки):
    # - Wall A: Between Study (Кабинет, width 2.75m) and New Bathroom (Санузел) at X = 89.7856, Y = -45.4244 .. -42.3044
    # - Wall B: Between New Bathroom (width 1.20m) and Staircase/Kitchen at X = 91.0856, Y = -45.4244 .. -42.3044
    # - Wall C: Horizontal corridor wall for Study & Bathroom doors at Y = -45.4244, X = 88.8856 .. 91.0856
    # - Wall D: Short vertical cheek wall separating Staircase/Appliance niche on Kitchen side at X = 93.3856, Y = -43.2544 .. -42.3044
    new_walls_data = [
        {'begCoordinate': {'x': 89.785596279, 'y': -45.424376912 + dy}, 'endCoordinate': {'x': 89.785596279, 'y': Y_TOP + dy}, 'height': 2.64, 'thickness': 0.10},
        {'begCoordinate': {'x': 91.085596279, 'y': -45.424376912 + dy}, 'endCoordinate': {'x': 91.085596279, 'y': Y_TOP + dy}, 'height': 2.64, 'thickness': 0.10},
        {'begCoordinate': {'x': 88.885596279, 'y': -45.424376912 + dy}, 'endCoordinate': {'x': 91.085596279, 'y': -45.424376912 + dy}, 'height': 2.64, 'thickness': 0.10},
        {'begCoordinate': {'x': 93.385596279, 'y': -43.254376912 + dy}, 'endCoordinate': {'x': 93.385596279, 'y': Y_TOP + dy}, 'height': 2.64, 'thickness': 0.10},
    ]
    rnw = tapir('CreateWalls', {'wallsData': new_walls_data})
    nw_list = rnw.get('result', {}).get('addOnCommandResponse', {}).get('walls', [])
    print(f"[dy={dy}] Created {len(nw_list)} new partitions")
    if nw_list:
        tapir('SetDetailsOfElements', {
            'elementsWithDetails': [{'elementId': w['elementId'], 'layerIndex': 8} for w in nw_list]
        })
        # Create Doors in Wall C (nw_list[2], length = 2.20m from 88.8856 to 91.0856):
        # - Door 1 (Study / Кабинет): centerOffset = 0.45m (width 0.80m)
        # - Door 2 (Bathroom / Санузел): centerOffset = 1.55m (width 0.70m)
        if len(nw_list) >= 3:
            rd = tapir('CreateDoors', {
                'doorsData': [
                    {'ownerWallId': nw_list[2]['elementId'], 'centerOffset': 0.45, 'width': 0.80, 'height': 2.10, 'sillHeight': 0.0, 'reflected': False, 'refSide': False, 'oSide': False},
                    {'ownerWallId': nw_list[2]['elementId'], 'centerOffset': 1.55, 'width': 0.70, 'height': 2.10, 'sillHeight': 0.0, 'reflected': False, 'refSide': True, 'oSide': False}
                ]
            })
            doors = rd.get('result', {}).get('addOnCommandResponse', {}).get('doors', [])
            print(f"[dy={dy}] Created {len(doors)} new doors")

    # 3. Create 2D Staircase Treads & Walkline on layer 8 (02_01 Новые перегородки) so it's crystal clear in 2D plan
    # Lower flight: X = 91.1356 .. 92.0356 (width 0.90m), Y from -45.3644 up to -43.2044 (8 steps x 0.27m = 2.16m)
    # Corner winder box: X = 91.1356 .. 92.0356, Y = -43.2044 .. -42.3044 (0.90 x 0.90m, 3 winder steps)
    # Upper flight: X from 92.0356 to 93.3856 (5 steps x 0.27m = 1.35m), Y = -43.2044 .. -42.3044 (width 0.90m)
    polys = []
    # Outer contour of L-stair
    polys.append({
        'layerIndex': 8,
        'linePenIndex': 1,
        'coordinates': [
            {'x': 91.1356, 'y': -45.3644 + dy},
            {'x': 92.0356, 'y': -45.3644 + dy},
            {'x': 92.0356, 'y': -43.2044 + dy},
            {'x': 93.3856, 'y': -43.2044 + dy},
            {'x': 93.3856, 'y': -42.3044 + dy},
            {'x': 91.1356, 'y': -42.3044 + dy},
            {'x': 91.1356, 'y': -45.3644 + dy}
        ]
    })
    # 8 treads on lower flight (every 0.27m)
    for i in range(1, 9):
        yi = -45.3644 + i * 0.27 + dy
        polys.append({
            'layerIndex': 8,
            'linePenIndex': 1,
            'coordinates': [{'x': 91.1356, 'y': yi}, {'x': 92.0356, 'y': yi}]
        })
    # 2 diagonal winder lines in corner (92.0356, -43.2044)
    polys.append({
        'layerIndex': 8,
        'linePenIndex': 1,
        'coordinates': [{'x': 92.0356, 'y': -43.2044 + dy}, {'x': 91.1356, 'y': -42.7544 + dy}]
    })
    polys.append({
        'layerIndex': 8,
        'linePenIndex': 1,
        'coordinates': [{'x': 92.0356, 'y': -43.2044 + dy}, {'x': 91.5856, 'y': -42.3044 + dy}]
    })
    # 5 treads on upper flight (every 0.27m from 92.0356 to 93.3856)
    for j in range(0, 5):
        xj = 92.0356 + j * 0.27
        polys.append({
            'layerIndex': 8,
            'linePenIndex': 1,
            'coordinates': [{'x': xj, 'y': -43.2044 + dy}, {'x': xj, 'y': -42.3044 + dy}]
        })
    # Walkline with arrow pointing East at top
    polys.append({
        'layerIndex': 8,
        'linePenIndex': 1,
        'coordinates': [
            {'x': 91.5856, 'y': -45.3644 + dy},
            {'x': 91.5856, 'y': -42.7544 + dy},
            {'x': 93.3856, 'y': -42.7544 + dy}
        ]
    })
    polys.append({
        'layerIndex': 8,
        'linePenIndex': 1,
        'coordinates': [
            {'x': 93.2056, 'y': -42.6344 + dy},
            {'x': 93.3856, 'y': -42.7544 + dy},
            {'x': 93.2056, 'y': -42.8744 + dy}
        ]
    })
    rp = tapir('CreatePolylines', {'polylinesData': polys})
    print(f"[dy={dy}] Created stair polylines:", len(rp.get('result', {}).get('addOnCommandResponse', {}).get('polylines', [])))

    # Also try native 3D Stair via CreateStairs on layer 8 so it appears in 3D too!
    rs = tapir('CreateStairs', {
        'stairsData': [{
            'baseLinePoints': [
                {'x': 91.5856, 'y': -45.3644 + dy},
                {'x': 91.5856, 'y': -42.7544 + dy},
                {'x': 93.3856, 'y': -42.7544 + dy}
            ],
            'zCoordinate': 0.0,
            'totalHeight': 3.00,
            'flightWidth': 0.90,
            'stepNum': 16
        }]
    })
    stairs = rs.get('result', {}).get('addOnCommandResponse', {}).get('stairs', [])
    if stairs:
        tapir('SetDetailsOfElements', {'elementsWithDetails': [{'elementId': s['elementId'], 'layerIndex': 8} for s in stairs]})
        print(f"[dy={dy}] Created 3D Stair:", len(stairs))

    # 4. Create Room Zones for Explication:
    # Variant 1 -> layerIndex = 14 (00_02 Экспликация новая)
    # Variant 2 -> layerIndex = 518 (00_02 Экспликация 2)
    z_layer = 518 if is_second_copy else 14
    zones_input = [
        {
            'name': 'Прихожая',
            'numberStr': '1',
            'stampPosition': {'x': 87.90, 'y': -45.90 + dy},
            'geometry': {'polygonCoordinates': [
                {'x': 86.9856, 'y': -46.8044 + dy},
                {'x': 88.7856, 'y': -46.8044 + dy},
                {'x': 88.7856, 'y': -45.0544 + dy},
                {'x': 86.9856, 'y': -45.0544 + dy}
            ]}
        },
        {
            'name': 'Кабинет / Гостевая',
            'numberStr': '2',
            'stampPosition': {'x': 88.30, 'y': -43.60 + dy},
            'geometry': {'polygonCoordinates': [
                {'x': 86.9856, 'y': -44.9544 + dy},
                {'x': 88.8856, 'y': -44.9544 + dy},
                {'x': 88.8856, 'y': -45.4244 + dy},
                {'x': 89.7356, 'y': -45.4244 + dy},
                {'x': 89.7356, 'y': -42.3044 + dy},
                {'x': 86.9856, 'y': -42.3044 + dy}
            ]}
        },
        {
            'name': 'Санузел',
            'numberStr': '3',
            'stampPosition': {'x': 90.43, 'y': -43.80 + dy},
            'geometry': {'polygonCoordinates': [
                {'x': 89.8356, 'y': -45.4244 + dy},
                {'x': 91.0356, 'y': -45.4244 + dy},
                {'x': 91.0356, 'y': -42.3044 + dy},
                {'x': 89.8356, 'y': -42.3044 + dy}
            ]}
        },
        {
            'name': 'Кухня-гостиная',
            'numberStr': '4',
            'stampPosition': {'x': 93.80, 'y': -44.80 + dy},
            'geometry': {'polygonCoordinates': [
                {'x': 88.8856, 'y': -46.8044 + dy},
                {'x': 96.0656, 'y': -46.8044 + dy},
                {'x': 96.0656, 'y': -42.3044 + dy},
                {'x': 91.1356, 'y': -42.3044 + dy},
                {'x': 91.1356, 'y': -45.4244 + dy},
                {'x': 88.8856, 'y': -45.4244 + dy}
            ]}
        }
    ]
    rz = tapir('CreateZones', {'zonesData': zones_input})
    z_list = rz.get('result', {}).get('addOnCommandResponse', {}).get('zones', [])
    print(f"[dy={dy}] Created {len(z_list)} zones")
    if z_list:
        tapir('SetDetailsOfElements', {
            'elementsWithDetails': [{'elementId': z['elementId'], 'layerIndex': z_layer} for z in z_list]
        })

# Build Variant 1 on main plan (dy = 0.0)
build_variant(0.0, is_second_copy=False)

# Build Variant 2 right above it (dy = +10.0)
build_variant(10.0, is_second_copy=True)
