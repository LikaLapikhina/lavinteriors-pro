import urllib.request, json

def api(cmd, params={}):
    req = urllib.request.Request('http://127.0.0.1:19724', data=json.dumps({'command': cmd, 'parameters': params}).encode('utf-8'), headers={'Content-Type': 'application/json'})
    return json.loads(urllib.request.urlopen(req, timeout=10).read().decode('utf-8'))['result']

def tapir(cmd, params={}):
    return api('API.ExecuteAddOnCommand', {'addOnCommandId': {'commandNamespace': 'TapirCommand', 'commandName': cmd}, 'addOnCommandParameters': params})['addOnCommandResponse']

# 1. Find and delete our previous newly created walls/polylines on layer 8 and 63 in Variant 1 & 2
els = tapir('GetAllElements', {})['elements']
det = tapir('GetDetailsOfElements', {'elements': els})['detailsOfElements']
bb = api('API.Get2DBoundingBoxes', {'elements': els})['boundingBoxes2D']

to_del = []
orig_outer_walls = []
for e, d, b in zip(els, det, bb):
    box = b.get('boundingBox2D', {})
    if not box or 'xMin' not in box: continue
    if box['xMin'] > 86.0 and box['xMax'] < 97.0 and box['yMin'] > -48.0 and box['yMax'] < -30.0:
        lid = d.get('layerIndex')
        eid = d.get('id', '')
        # Delete everything in Variant 2 (y > -39)
        if box['yMin'] > -39.0:
            to_del.append(e)
        # In Variant 1, delete our generated walls (СТН-091, СТН-097) and polylines on layer 8/63
        elif lid in [8, 63] and d.get('type') in ['Wall', 'PolyLine', 'Door', 'Window']:
            to_del.append(e)
        # Keep original outer walls СТН-011..016 and move them to layer 63 so they don't shift 250mm inside!
        elif eid in ['СТН-011', 'СТН-012', 'СТН-013', 'СТН-014', 'СТН-015', 'СТН-016', 'ОК-002', 'ОК-003', 'ДВ-001', 'ДВ-003']:
            orig_outer_walls.append((e, d))

if to_del:
    tapir('DeleteElements', {'elements': to_del})

# Also check by coordinates for original outer walls (since Cyrillic id might be encoded)
els = tapir('GetAllElements', {})['elements']
det = tapir('GetDetailsOfElements', {'elements': els})['detailsOfElements']
bb = api('API.Get2DBoundingBoxes', {'elements': els})['boundingBoxes2D']
set_63 = []
for e, d, b in zip(els, det, bb):
    box = b.get('boundingBox2D', {})
    if not box or 'xMin' not in box: continue
    if box['xMin'] > 86.0 and box['xMax'] < 97.0 and box['yMin'] > -48.0 and box['yMax'] < -41.0:
        if d.get('layerIndex') == 56 and d.get('type') in ['Wall', 'Window', 'Door', 'Opening']:
            set_63.append({'elementId': e['elementId'], 'layerIndex': 63})
        elif d.get('layerIndex') == 5 and d.get('type') in ['Wall', 'Door']:
            # Demolished partitions СТН-018, 021, 023, 024 -> layer 62 (hidden on Planning view)
            set_63.append({'elementId': e['elementId'], 'layerIndex': 62})

if set_63:
    tapir('SetDetailsOfElements', {'elementsWithDetails': set_63})

# 2. Now create the EXACT new partitions and mirrored staircase strictly inside the "Каркас лестницы" opening from Обмерный план Кривцово-2.pdf:
# Exact coordinates from Обмерный план Кривцово-2.pdf:
# Top inner wall face: Y_top = -42.304376912
# Left inner wall face: X_left = 86.985596279
# Entry partition right face: X_entry = 88.885596279
# Old central wall СТН-018: X = 91.8656 .. 91.9656, Y = -45.4244 .. -42.3044
# Old bathroom left wall СТН-023: X = 90.6156 .. 90.7156, Y = -45.4244 .. -43.7444
# Old bathroom top wall СТН-024: Y = -43.8444 .. -43.7444, X = 90.6156 .. 91.9656
# EXACT "Каркас лестницы" (red dashed opening on measurement plan):
#   - Upper-left part (between СТН-024 and top wall): X = 90.6956 .. 91.8656 (width 1.17m), Y = -43.7444 .. -42.3044 (depth 1.44m)
#   - Right vertical flight (to the right of СТН-018): X = 91.9656 .. 92.7656 (width 0.80m), Y = -44.6044 .. -42.3044 (length 2.30m)
# Note: CreateWalls centers thickness on begCoordinate..endCoordinate!
# So for a 100mm wall (0.10m), center line is at face +/- 0.05m:
# 1) Wall between Staircase right flight and Bathroom/Under-stair niche:
#    From Y = -45.4244 to Y = -43.7444 at X = 91.9156 (exact position of СТН-018 lower part, keeping the 1440mm upper part open to the kitchen as the under-stair "аппендицит"!)
# 2) Wall closing the back of the under-stair niche ("аппендицит") from the Bathroom/Study:
#    At X = 90.6656 (x=[90.6156..90.7156]), from Y = -43.7444 to Y = -42.3044
#    And horizontal wall at Y = -43.7944 (y=[-43.8444..-43.7444]), from X = 90.6656 to X = 91.9156
# 3) Shifted Bathroom (moved left into the room as on neighbor's plan, or keeping exact wall positions):
#    Wait: let's check where the bathroom is when the staircase is mirrored!
#    Wait: On the measurement plan, the staircase frame is ALREADY at X=90.6956..92.7656!
#    Why? Because in the original developer plan (140226_01.jpg), the bathroom was at X=90.6156..91.9656, Y=-45.4244..-43.7444!
#    Let's check: in the measurement plan (Обмерный план Кривцово-2.pdf), the red dashed line IS the existing staircase opening:
#      - Flight 1 along X = 91.9656 .. 92.7656, Y = -44.6044 .. -42.3044 (2300 x 800 mm)
#      - Turn & Flight 2 along X = 90.6956 .. 91.9656, Y = -43.7444 .. -42.3044 (1170+100 x 1440 mm)

walls_data = [
    # Corridor bottom wall (Y = -45.4744 center -> [-45.5244..-45.4244]) from X=88.8856 to X=91.9656
    {'begCoordinate': {'x': 88.885596, 'y': -45.474377}, 'endCoordinate': {'x': 91.965596, 'y': -45.474377}, 'height': 2.64, 'thickness': 0.10},
    # Wall between Study and Bathroom/Staircase: X = 90.6656 ([-90.6156..90.7156]) from Y = -45.4244 to Y = -42.3044
    {'begCoordinate': {'x': 90.665596, 'y': -45.424377}, 'endCoordinate': {'x': 90.665596, 'y': -42.304377}, 'height': 2.64, 'thickness': 0.10},
    # Wall between Bathroom and Under-stair niche: Y = -43.7944 ([-43.8444..-43.7444]) from X = 90.6656 to X = 91.9656
    {'begCoordinate': {'x': 90.665596, 'y': -43.794377}, 'endCoordinate': {'x': 91.965596, 'y': -43.794377}, 'height': 2.64, 'thickness': 0.10},
    # Wall between Bathroom and Staircase flight (lower part of СТН-018, leaving the 1440mm under-stair niche open to kitchen!):
    # X = 91.9156 ([91.8656..91.9656]) from Y = -45.4244 to Y = -43.7444
    {'begCoordinate': {'x': 91.915596, 'y': -45.424377}, 'endCoordinate': {'x': 91.915596, 'y': -43.744377}, 'height': 2.64, 'thickness': 0.10},
]

rw = tapir('CreateWalls', {'wallsData': walls_data})
new_wall_els = rw.get('elements', [])
if new_wall_els:
    tapir('SetDetailsOfElements', {'elementsWithDetails': [{'elementId': w['elementId'], 'layerIndex': 8} for w in new_wall_els]})
    # Add doors in Corridor wall (new_wall_els[0]): Study door (0.85m) and Bathroom door (0.75m)
    w0_guid = new_wall_els[0]['elementId']['guid']
    rd = tapir('CreateDoors', {'doorsData': [
        {'ownerWallId': {'guid': w0_guid}, 'centerOffset': 0.65, 'width': 0.85, 'height': 2.10, 'sillHeight': 0.0, 'reflected': False, 'refSide': False, 'oSide': False},
        {'ownerWallId': {'guid': w0_guid}, 'centerOffset': 2.40, 'width': 0.75, 'height': 2.10, 'sillHeight': 0.0, 'reflected': False, 'refSide': True, 'oSide': False}
    ]})
    if rd.get('elements'):
        tapir('SetDetailsOfElements', {'elementsWithDetails': [{'elementId': d['elementId'], 'layerIndex': 8} for d in rd['elements']]})

# 3. Draw the EXACT Staircase Polylines strictly matching the measurement plan's "Каркас лестницы" (2300x800 right flight + 1440x1170 left turn), mirrored so climb starts at bottom of right flight (Y=-44.6044) and goes up to left turn (X=90.7156):
x_st_left = 90.715596     # inner right face of wall X=90.6656 (1150mm to 91.8656, 1250mm to 91.9656)
x_st_mid  = 91.965596     # right face of СТН-018
x_st_right = 92.765596    # 91.9656 + 0.800m = 92.7656 (exact 800mm from measurement plan!)
y_st_top  = -42.304377    # exact inner face of top outer wall СТН-013!
y_st_turn = -43.744377    # exact -42.3044 - 1.440m = -43.7444 (exact 1440mm from measurement plan!)
y_st_bot  = -44.604377    # exact -42.3044 - 2.300m = -44.6044 (exact 2300mm from measurement plan!)

polys = []
def add_poly(pts):
    polys.append({'layerIndex': 8, 'linePenIndex': 1, 'coordinates': [{'x': p[0], 'y': p[1]} for p in pts]})

# Outer contour of staircase in the exact opening:
add_poly([
    (x_st_mid, y_st_bot),
    (x_st_right, y_st_bot),
    (x_st_right, y_st_top),
    (x_st_left, y_st_top),
    (x_st_left, y_st_turn),
    (x_st_mid, y_st_turn),
    (x_st_mid, y_st_bot)
])

# Lower flight treads (from y_st_bot = -44.6044 up to y = -43.1044 -> 1.50m = 6 steps x 250mm)
y_winder_bot = y_st_top - 0.80  # -43.1044
n_lower = 6
for i in range(n_lower + 1):
    yy = y_st_bot + i * (y_winder_bot - y_st_bot) / n_lower
    add_poly([(x_st_mid, yy), (x_st_right, yy)])

# Winder steps in the top-right corner (x=[91.9656..92.7656], y=[-43.1044..-42.3044])
add_poly([(x_st_mid, y_winder_bot), (x_st_right, y_st_top)])
add_poly([(x_st_mid, y_winder_bot), (x_st_mid, y_st_top)])

# Upper flight / turn in the 1250 x 1440 box (x=[90.7156..91.9656], y=[-43.7444..-42.3044])
# exactly matching the winder rays on Обмерный план Кривцово-2.pdf:
add_poly([(x_st_mid, y_st_turn), (x_st_left + 0.40, y_st_top)])
add_poly([(x_st_mid, y_st_turn), (x_st_left, y_st_top)])
add_poly([(x_st_mid, y_st_turn), (x_st_left, y_st_turn + 0.72)])

# Walkline with arrow (climbing UP from bottom of right flight, turning left into the 1440x1170 opening):
xm = (x_st_mid + x_st_right) / 2.0
ym = (y_st_top + y_st_turn) / 2.0
add_poly([
    (xm, y_st_bot),
    (xm, ym),
    (x_st_left + 0.25, ym)
])
# Arrowhead pointing left at (x_st_left + 0.25, ym):
add_poly([
    (x_st_left + 0.40, ym + 0.10),
    (x_st_left + 0.25, ym),
    (x_st_left + 0.40, ym - 0.10)
])

rp = tapir('CreatePolylines', {'polylinesData': polys})
if rp.get('elements'):
    tapir('SetDetailsOfElements', {'elementsWithDetails': [{'elementId': p['elementId'], 'layerIndex': 8} for p in rp['elements']]})

print("DONE! Outer walls restored, staircase placed strictly in the measurement plan opening.")
