import urllib.request, json, sys
sys.stdout.reconfigure(encoding='utf-8')

def ac_post(cmd, params=None):
    req = urllib.request.Request(
        'http://127.0.0.1:19724',
        data=json.dumps({'command': cmd, 'parameters': params or {}}).encode('utf-8'),
        headers={'Content-Type': 'application/json'}
    )
    return json.loads(urllib.request.urlopen(req, timeout=30).read().decode('utf-8'))

def tapir(cmd, params=None):
    res = ac_post('API.ExecuteAddOnCommand', {
        'addOnCommandId': {'commandNamespace': 'TapirCommand', 'commandName': cmd},
        'addOnCommandParameters': params or {}
    })
    return res.get('result', {}).get('addOnCommandResponse', {})

# 1. Clean up all newly created elements (those at X > 80 that are NOT part of original 102 Krivtsovo elements)
# Original Krivtsovo elements had IDs СТН-011..024, ОК-002..003, ДВ-001..004, КОЛ-002..004, or are on layers 4, 5, 6, 56 at Y < -40
all_el = tapir('GetAllElements').get('elements', [])
bboxes = ac_post('API.Get2DBoundingBoxes', {'elements': all_el}).get('result', {}).get('boundingBoxes2D', [])
dets = tapir('GetDetailsOfElements', {'elements': all_el}).get('detailsOfElements', [])

orig_wall_guids = {
    '6B446130-6161-4D28-8A87-13715CB9C9A0',
    '93DE1068-5CF6-4F39-A28C-AC3A628BE203',
    '464571A9-197D-4363-BBA3-80F234EC4711',
    'E254F132-6286-4FA5-A71F-71A0120CD99B',
    '5833CDAF-845A-4BD5-A17C-4A976CE306DB',
    '6F3157B1-2690-416D-80C4-07387F6E8E35',
    '39E3771B-7321-4F3B-B398-D63F120A3636',
    'F193E07D-503F-4860-B331-1AECC35BFDC0',
    'DA4B021B-395A-40B1-8F60-E56C3497EFA1',
    '3D22AFAB-865B-423F-A11B-A2DC931451BD',
}

to_del = []
for el, bb, d in zip(all_el, bboxes, dets):
    b = bb.get('boundingBox2D') or {}
    x = b.get('xMin')
    y = b.get('yMin')
    g = el['elementId']['guid']
    t = d.get('type')
    li = d.get('layerIndex')
    if x is not None and x > 80.0:
        if y is not None and y > -40.0:
            to_del.append(el)
        elif t == 'Wall' and g not in orig_wall_guids:
            to_del.append(el)
        elif t in ('Stair', 'Zone'):
            to_del.append(el)
        elif t == 'PolyLine' and li in (8, 17, 63):
            to_del.append(el)

if to_del:
    tapir('DeleteElements', {'elements': to_del})
    print("Deleted previous test elements:", len(to_del))

X_LEFT = 86.985596279
X_RIGHT = 96.065596279
Y_BOT = -46.804376912
Y_TOP = -42.304376912

def build_clean_variant(dy, is_second_copy=False):
    # Create outer walls + entry niche and set layerIndex = 63 (visible in 04 Планировочное решение!)
    outer_walls_data = [
        {'begCoordinate': {'x': X_LEFT, 'y': Y_BOT + dy}, 'endCoordinate': {'x': X_RIGHT, 'y': Y_BOT + dy}, 'height': 2.64, 'thickness': 0.50},
        {'begCoordinate': {'x': X_RIGHT, 'y': Y_BOT + dy}, 'endCoordinate': {'x': X_RIGHT, 'y': Y_TOP + dy}, 'height': 2.64, 'thickness': 0.50},
        {'begCoordinate': {'x': X_RIGHT, 'y': Y_TOP + dy}, 'endCoordinate': {'x': X_LEFT, 'y': Y_TOP + dy}, 'height': 2.64, 'thickness': 0.50},
        {'begCoordinate': {'x': X_LEFT, 'y': Y_TOP + dy}, 'endCoordinate': {'x': X_LEFT, 'y': Y_BOT + dy}, 'height': 2.64, 'thickness': 0.50},
        {'begCoordinate': {'x': X_LEFT, 'y': -44.954376912 + dy}, 'endCoordinate': {'x': 88.885596279, 'y': -44.954376912 + dy}, 'height': 2.64, 'thickness': 0.10},
        {'begCoordinate': {'x': 88.885596279, 'y': -44.954376912 + dy}, 'endCoordinate': {'x': 88.885596279, 'y': Y_BOT + dy}, 'height': 2.64, 'thickness': 0.10},
    ]
    rw = tapir('CreateWalls', {'wallsData': outer_walls_data})
    ow_list = rw.get('elements', [])
    print(f"[dy={dy}] Outer walls created: {len(ow_list)}")
    if len(ow_list) == 6:
        details_payload = []
        for idx, w in enumerate(ow_list):
            th = 0.50 if idx < 4 else 0.10
            details_payload.append({
                'elementId': w['elementId'],
                'layerIndex': 63,
                'details': {
                    'begThickness': th,
                    'endThickness': th,
                    'height': 2.64,
                    'flipped': False,
                    'offset': 0.0
                }
            })
        tapir('SetDetailsOfElements', {'elementsWithDetails': details_payload})

        rw_win = tapir('CreateWindows', {
            'windowsData': [
                {'ownerWallId': ow_list[1]['elementId'], 'centerOffset': 2.235, 'width': 2.81, 'height': 2.08, 'sillHeight': 0.19, 'reflected': True, 'refSide': True, 'oSide': True},
                {'ownerWallId': ow_list[3]['elementId'], 'centerOffset': 1.51, 'width': 1.78, 'height': 1.91, 'sillHeight': 0.58, 'reflected': True, 'refSide': True, 'oSide': False}
            ]
        })
        rd_ext = tapir('CreateDoors', {
            'doorsData': [
                {'ownerWallId': ow_list[3]['elementId'], 'centerOffset': 3.895, 'width': 0.99, 'height': 2.11, 'sillHeight': 0.13, 'reflected': True, 'refSide': True, 'oSide': False},
                {'ownerWallId': ow_list[5]['elementId'], 'centerOffset': 1.295, 'width': 0.91, 'height': 2.30, 'sillHeight': 0.0, 'reflected': True, 'refSide': True, 'oSide': False}
            ]
        })

    if is_second_copy:
        rc = tapir('CreateColumns', {
            'columnsData': [
                {'coordinates': {'x': 93.290596279, 'y': -42.509376912 + dy, 'z': 0.0}},
                {'coordinates': {'x': 93.460727412, 'y': -42.588286466 + dy, 'z': 0.0}},
                {'coordinates': {'x': 91.602684295, 'y': -44.021767609 + dy, 'z': 0.0}},
                {'coordinates': {'x': 90.693313500, 'y': -45.442575798 + dy, 'z': 0.0}}
            ]
        })
        cols = rc.get('elements', [])
        if cols:
            tapir('SetDetailsOfElements', {
                'elementsWithDetails': [{'elementId': c['elementId'], 'layerIndex': 4} for c in cols]
            })

    # 2. New Redesigned Partitions on layer 8 (02_01 Новые перегородки), thickness = 0.10m
    new_walls_data = [
        {'begCoordinate': {'x': 89.835596279, 'y': -45.424376912 + dy}, 'endCoordinate': {'x': 89.835596279, 'y': Y_TOP + dy}, 'height': 2.64, 'thickness': 0.10},
        {'begCoordinate': {'x': 91.135596279, 'y': -45.424376912 + dy}, 'endCoordinate': {'x': 91.135596279, 'y': Y_TOP + dy}, 'height': 2.64, 'thickness': 0.10},
        {'begCoordinate': {'x': 88.885596279, 'y': -45.424376912 + dy}, 'endCoordinate': {'x': 91.135596279, 'y': -45.424376912 + dy}, 'height': 2.64, 'thickness': 0.10},
        {'begCoordinate': {'x': 93.385596279, 'y': -43.204376912 + dy}, 'endCoordinate': {'x': 93.385596279, 'y': Y_TOP + dy}, 'height': 2.64, 'thickness': 0.10},
    ]
    rnw = tapir('CreateWalls', {'wallsData': new_walls_data})
    nw_list = rnw.get('elements', [])
    print(f"[dy={dy}] New partitions created: {len(nw_list)}")
    if nw_list:
        tapir('SetDetailsOfElements', {
            'elementsWithDetails': [{
                'elementId': w['elementId'],
                'layerIndex': 8,
                'details': {
                    'begThickness': 0.10,
                    'endThickness': 0.10,
                    'height': 2.64,
                    'flipped': False,
                    'offset': 0.0
                }
            } for w in nw_list]
        })
        if len(nw_list) >= 3:
            rd = tapir('CreateDoors', {
                'doorsData': [
                    {'ownerWallId': nw_list[2]['elementId'], 'centerOffset': 0.425, 'width': 0.80, 'height': 2.10, 'sillHeight': 0.0, 'reflected': False, 'refSide': False, 'oSide': False},
                    {'ownerWallId': nw_list[2]['elementId'], 'centerOffset': 1.55, 'width': 0.70, 'height': 2.10, 'sillHeight': 0.0, 'reflected': False, 'refSide': True, 'oSide': False}
                ]
            })
            print(f"[dy={dy}] Doors created:", len(rd.get('elements', [])))

    # 3. 2D Staircase on layer 8 (02_01 Новые перегородки)
    polys = []
    polys.append({
        'layerIndex': 8,
        'linePenIndex': 1,
        'coordinates': [
            {'x': 91.1356, 'y': -45.3644 + dy},
            {'x': 92.0356, 'y': -45.3644 + dy},
            {'x': 92.0356, 'y': -43.2044 + dy},
            {'x': 93.3856, 'y': -43.2044 + dy},
            {'x': 93.3856, 'y': -42.3044 + dy},
            {'x': 91.1356, 'y': -42.3044 + dy},
            {'x': 91.1356, 'y': -45.3644 + dy}
        ]
    })
    for i in range(1, 9):
        yi = -45.3644 + i * 0.27 + dy
        polys.append({'layerIndex': 8, 'linePenIndex': 1, 'coordinates': [{'x': 91.1356, 'y': yi}, {'x': 92.0356, 'y': yi}]})
    polys.append({'layerIndex': 8, 'linePenIndex': 1, 'coordinates': [{'x': 92.0356, 'y': -43.2044 + dy}, {'x': 91.1356, 'y': -42.7544 + dy}]})
    polys.append({'layerIndex': 8, 'linePenIndex': 1, 'coordinates': [{'x': 92.0356, 'y': -43.2044 + dy}, {'x': 91.5856, 'y': -42.3044 + dy}]})
    for j in range(0, 5):
        xj = 92.0356 + j * 0.27
        polys.append({'layerIndex': 8, 'linePenIndex': 1, 'coordinates': [{'x': xj, 'y': -43.2044 + dy}, {'x': xj, 'y': -42.3044 + dy}]})
    polys.append({'layerIndex': 8, 'linePenIndex': 1, 'coordinates': [{'x': 91.5856, 'y': -45.3644 + dy}, {'x': 91.5856, 'y': -42.7544 + dy}, {'x': 93.3856, 'y': -42.7544 + dy}]})
    polys.append({'layerIndex': 8, 'linePenIndex': 1, 'coordinates': [{'x': 93.2056, 'y': -42.6344 + dy}, {'x': 93.3856, 'y': -42.7544 + dy}, {'x': 93.2056, 'y': -42.8744 + dy}]})
    rp = tapir('CreatePolylines', {'polylinesData': polys})
    print(f"[dy={dy}] Stair polylines created: {len(rp.get('elements', []))}")

    # 4. Zones on layer 14 (Вариант 1) and layer 518 (Вариант 2)
    z_layer = 518 if is_second_copy else 14
    zones_input = [
        {
            'name': 'Прихожая',
            'numberStr': '1',
            'stampPosition': {'x': 87.90, 'y': -45.90 + dy},
            'geometry': {'polygonCoordinates': [
                {'x': 86.9856, 'y': -46.8044 + dy},
                {'x': 88.7856, 'y': -46.8044 + dy},
                {'x': 88.7856, 'y': -45.0544 + dy},
                {'x': 86.9856, 'y': -45.0544 + dy}
            ]}
        },
        {
            'name': 'Кабинет / Гостевая',
            'numberStr': '2',
            'stampPosition': {'x': 88.30, 'y': -43.60 + dy},
            'geometry': {'polygonCoordinates': [
                {'x': 86.9856, 'y': -44.9544 + dy},
                {'x': 88.8856, 'y': -44.9544 + dy},
                {'x': 88.8856, 'y': -45.4244 + dy},
                {'x': 89.7356, 'y': -45.4244 + dy},
                {'x': 89.7356, 'y': -42.3044 + dy},
                {'x': 86.9856, 'y': -42.3044 + dy}
            ]}
        },
        {
            'name': 'Санузел',
            'numberStr': '3',
            'stampPosition': {'x': 90.43, 'y': -43.80 + dy},
            'geometry': {'polygonCoordinates': [
                {'x': 89.8356, 'y': -45.4244 + dy},
                {'x': 91.0356, 'y': -45.4244 + dy},
                {'x': 91.0356, 'y': -42.3044 + dy},
                {'x': 89.8356, 'y': -42.3044 + dy}
            ]}
        },
        {
            'name': 'Кухня-гостиная',
            'numberStr': '4',
            'stampPosition': {'x': 93.80, 'y': -44.80 + dy},
            'geometry': {'polygonCoordinates': [
                {'x': 88.8856, 'y': -46.8044 + dy},
                {'x': 96.0656, 'y': -46.8044 + dy},
                {'x': 96.0656, 'y': -42.3044 + dy},
                {'x': 91.1356, 'y': -42.3044 + dy},
                {'x': 91.1356, 'y': -45.4244 + dy},
                {'x': 88.8856, 'y': -45.4244 + dy}
            ]}
        }
    ]
    rz = tapir('CreateZones', {'zonesData': zones_input})
    z_list = rz.get('elements', [])
    print(f"[dy={dy}] Zones created: {len(z_list)}")
    if z_list:
        tapir('SetDetailsOfElements', {
            'elementsWithDetails': [{'elementId': z['elementId'], 'layerIndex': z_layer} for z in z_list]
        })

build_clean_variant(0.0, is_second_copy=False)
build_clean_variant(10.0, is_second_copy=True)
