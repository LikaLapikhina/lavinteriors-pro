import json

with open(r'C:\Users\Анжелика\.gemini\antigravity\brain\87f654cc-c203-4def-bc47-8ebe20bacda9\.system_generated\logs\transcript_full.jsonl', 'r', encoding='utf-8') as f:
    line = json.loads(f.readline())
    text = line['content']
    for i, part in enumerate(text.split('.')):
        if any(w in part.lower() for w in ['лестн', 'каркас', 'сануз', 'проем', 'проём', 'аппендиц', 'стен', 'зеркал']):
            print(f"[{i}] {part.strip()}.")
