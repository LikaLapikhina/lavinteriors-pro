@[lav-design-core](C:/Users/Анжелика/.gemini/config/rules/lav-design-core.md)
