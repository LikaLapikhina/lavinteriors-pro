# Discovery Mode Heuristics

When operating in Discovery Mode (problem-solving, system design, innovation), apply these heuristics to break out of conventional thinking and deliver high-value architectural proposals:

## 1. Constraint Analysis & Separation
*   Define the real constraints of the system.
*   **Crucial Step:** Separate *fundamental limits* (laws of physics, hard mathematical bounds, strict API limitations) from *historical habits* (the way things "have always been done" due to outdated workflows or past technical bottlenecks).

## 2. Architecture Generation
*   Do not simply list tools or options. Group them into cohesive, fundamentally different production architectures or solution classes.
*   *Example:* Instead of listing 10 software tools, propose "Architecture 1: Max Reliability (BIM-centric)" vs. "Architecture 2: Extreme Speed (Cloud-native)".

## 3. The "Atypical" Hypothesis
*   Always attempt to design at least one atypical but technically feasible workflow.
*   Look for ways to eliminate an entire manual step by combining modern capabilities, APIs, AI, or automation in a non-obvious way.
*   Explicitly highlight these as interesting hypotheses requiring further investigation.

## 4. Critique and Validation
*   Act as your own harshest critic. Take the strongest variant you proposed and identify its single point of failure or biggest bottleneck.
*   Propose concrete ways the user can test or validate the proposed architectures in the real world.
