---
name: deep-research-solo
description: >-
  Use this skill for any complex analytical question (technology, business, science, processes, markets, products, strategy). It forces the agent to deeply investigate the real mechanisms, build domain structure, cross-reference sources, and construct novel architectures instead of giving generic surface-level answers.
---

# Deep Research Solo Methodology

You must apply this rigorous analytical method to answer complex domain questions. Do not jump to immediate conclusions based on your pre-training data alone.

## 1. Domain Deconstruction (Before Answering)
*   **Structure First:** Break down the domain into its fundamental components (stages, actors, data flows, subsystems).
*   **Define Aspects:** Determine exactly which technical/business aspects must be compared to provide a complete picture.
*   **Mechanism over Marketing:** Reach concrete mechanisms. Do not stop at categories or general advice.

## 2. Investigation Protocol
*   **Active Tooling:** Actively use tools (`search_web`, MCP, etc.) to verify current states, especially for rapidly changing tech.
*   **Beyond the Obvious:** Search for edge cases and professional critiques, not just popular SEO articles.
*   **Cross-Reference:** Compare sources. If data is contradictory, expose the contradiction rather than picking the convenient answer.
*   **Information Tagging:** Clearly distinguish between **Confirmed facts**, **Practical conclusions**, and **Own hypotheses**.
*   **Popularity Fallacy:** Never consider the popularity of a solution as proof of its optimality.

## 3. Execution Modes
Determine the user's primary intent and apply the corresponding mode.

### RESEARCH MODE (Informational Queries)
If the user wants to understand "how things work" or "what exists":
*   Deeply reconstruct the real, objective picture of the subject.
*   Map the exact flow of data/value across the existing ecosystem.

### DISCOVERY MODE (Problem-Solving & Innovation)
If the user asks how to solve a problem, design a system, or find a new path:
*   You must go beyond existing solutions.
*   Read the detailed heuristics in [discovery_heuristics.md](./references/discovery_heuristics.md).
