---
name: deep-research-team
description: >-
  Methodology for orchestrating multi-agent research on complex, open-ended problems. 
  Use in conjunction with /teamwork-preview or invoke_subagent for deep research, 
  tool analysis, or invention. Ensures independent thinking, rigorous fact-checking, 
  and critical auditing.
---

# Deep Research Team Methodology

This skill defines the orchestration protocol for conducting multi-agent research. When acting as the lead orchestrator, do not mechanically divide a report into chapters. Instead, divide the *solution space* into independent analytical vectors to prevent groupthink.

## 1. Core Principles

- **Map the Unknowns:** Before launching subagents, formalize the problem and build a map of the workflow stages, unknowns, or technological boundaries.
- **Independent Vectors:** Assign subagents to fundamentally different classes of solutions or tools. Ensure one agent's early hypothesis does not become a premise for the entire team.
- **Fact-Based Verification:** Instruct agents to verify claims against actual documentation, API limits, and specific tool behaviors rather than marketing descriptions.
- **The Critical Auditor (Red Team):** Always deploy at least one separate subagent dedicated exclusively to finding errors, outdated practices, hidden limitations, double sources of truth, and interoperability data loss.
- **Strict Synthesis:** The final output must explicitly separate:
  - Confirmed capabilities (with technical proof)
  - Team conclusions
  - Hypotheses
  - Unconfirmed or disputed claims

## 2. Modes of Operation

When initializing the team, clarify which mode is active based on the user's request.

### Mode A: DEEP RESEARCH
**Goal:** Achieve maximum completeness and accuracy in understanding the subject.
- **Action:** Deploy specialized agents to dig vertically into specific domains.
- **Synthesis:** Aggregate findings, resolve contradictions (or explicitly highlight them if unresolved), and provide a definitive map of the current landscape.

### Mode B: DISCOVERY / INVENTION
**Goal:** Map the existing space, find unfilled capability combinations, and synthesize completely new, atypical solution variants.
- **Phase 1 (Mapping):** Agents independently research capabilities and bottlenecks.
- **Phase 2 (Ideation):** Generate several fundamentally different candidate architectures or solutions.
- **Phase 3 (Stress-Test):** Subject the strongest candidates to critical auditing. Look for reasons why "standard limitations" might not actually be fundamental constraints.
- **Phase 4 (Second Generation Pass):** Combine compatible strong ideas into a new hybrid solution.
- **Phase 5 (Output):** Conclude with specific, testable hypotheses or concrete experiments for further validation.

## 3. Execution Steps

1. **Acknowledge and Formalize:** Output the problem map and the research strategy to the user.
2. **Define and Invoke:** Use `define_subagent` and `invoke_subagent` to launch:
   - 2-3 Domain Expert Agents (with strict instructions to verify facts).
   - 1 Red Team Auditor Agent (with instructions to aggressively challenge norms).
3. **Wait for Findings:** Wait for the subagents to complete their independent research. Do not intervene unless an agent gets stuck.
4. **Evaluate and Synthesize:** Review the incoming data. If running in DISCOVERY mode, perform the second generation pass.
5. **Final Report:** Produce the final artifact adhering to the strict synthesis rules.
