/**
 * Единый браузерный помощник столярных узлов, фасадов, дизайнерских ручек, классической фрезеровки,
 * раковин из керамогранита со скошенным сливом и потолков для Homestyler (hs_joinery_engine.js)
 *
 * Подключается автоматически через панель http://127.0.0.1:3033/hs-joinery.js
 * Доступен в окне браузера как: window.HSJoinery, window.HSJoineryEngine, window.HSDesignerHandles
 *
 * ЭТАЛОНЫ В ПАПКЕ: C:\Users\Анжелика\.gemini\config\skills\homestyler-studio\references\
 * - handles\01..06 (современные врезные, торцевые, капсульные и верхние профильные ручки 3ddd)
 * - facades\01..03 (неоклассическая и классическая многоступенчатая фрезеровка фасадов с филёнкой)
 * - sinks\01_porcelain_sloped_slot_drain_sink.jpg (раковина из керамогранита со скошенным дном и лотком для слива)
 */

(function () {
  const getTargetWindow = () => {
    let w = window;
    if (!w.HSApp || !w.HSApp.App) {
      const iframes = Array.from(document.querySelectorAll('iframe'));
      for (const ifr of iframes) {
        try {
          if (ifr.contentWindow && ifr.contentWindow.HSApp && ifr.contentWindow.HSApp.App) {
            w = ifr.contentWindow;
            break;
          }
        } catch (e) {}
      }
    }
    return w;
  };

  /**
   * Контуры дизайнерских врезных и профильных ручек в 2D-координатах фасада (s: 0..W, z: 0..H)
   */
  const Handles = {
    // ТИП 1 (Референсы handles\01 и handles\04): Боковая торцевая выемка со скосами 45°
    buildFacadeWithChamferSlot(W, H, side = 'right', yBottom = 900, yTop = 1200, cutWidth = 20, chamfer = 25) {
      const c = Math.max(cutWidth, chamfer);
      if (side === 'right') {
        const pts = [{ x: 0, y: 0 }, { x: 0, y: H }];
        if (yTop >= H - 1) {
          pts.push({ x: W - cutWidth, y: H });
        } else {
          pts.push({ x: W, y: H });
          pts.push({ x: W, y: Math.min(H, yTop + c) });
          pts.push({ x: W - cutWidth, y: yTop });
        }
        if (yBottom <= 1) {
          pts.push({ x: W - cutWidth, y: 0 });
        } else {
          pts.push({ x: W - cutWidth, y: yBottom });
          pts.push({ x: W, y: Math.max(0, yBottom - c) });
          pts.push({ x: W, y: 0 });
        }
        return pts;
      } else {
        const pts = [];
        if (yBottom <= 1) {
          pts.push({ x: cutWidth, y: 0 });
        } else {
          pts.push({ x: 0, y: 0 });
          pts.push({ x: 0, y: Math.max(0, yBottom - c) });
          pts.push({ x: cutWidth, y: yBottom });
        }
        if (yTop >= H - 1) {
          pts.push({ x: cutWidth, y: H });
        } else {
          pts.push({ x: cutWidth, y: yTop });
          pts.push({ x: 0, y: Math.min(H, yTop + c) });
          pts.push({ x: 0, y: H });
        }
        pts.push({ x: W, y: H }, { x: W, y: 0 });
        return pts;
      }
    },

    // ТИП 2 (Референс handles\01): Круглая или вертикальная капсульная выемка на торце фасада
    buildFacadeWithArcOrCapsuleSlot(W, H, side = 'right', yCenter = 1050, radius = 65, straightHeight = 0, arcSegments = 16) {
      const halfStraight = straightHeight / 2;
      const yTopArcCenter = yCenter + halfStraight;
      const yBotArcCenter = yCenter - halfStraight;
      if (side === 'right') {
        const pts = [{ x: 0, y: 0 }, { x: 0, y: H }, { x: W, y: H }];
        for (let i = 0; i <= arcSegments; i++) {
          const t = (Math.PI / 2) * (i / arcSegments);
          pts.push({ x: W - radius * Math.sin(t), y: yTopArcCenter + radius * Math.cos(t) });
        }
        for (let i = 0; i <= arcSegments; i++) {
          const t = (Math.PI / 2) * (i / arcSegments);
          pts.push({ x: W - radius * Math.cos(t), y: yBotArcCenter - radius * Math.sin(t) });
        }
        pts.push({ x: W, y: 0 });
        return pts;
      } else {
        const pts = [{ x: 0, y: 0 }];
        for (let i = 0; i <= arcSegments; i++) {
          const t = (Math.PI / 2) * (i / arcSegments);
          pts.push({ x: radius * Math.sin(t), y: yBotArcCenter - radius * Math.cos(t) });
        }
        for (let i = 0; i <= arcSegments; i++) {
          const t = (Math.PI / 2) * (i / arcSegments);
          pts.push({ x: radius * Math.cos(t), y: yTopArcCenter + radius * Math.sin(t) });
        }
        pts.push({ x: 0, y: H }, { x: W, y: H }, { x: W, y: 0 });
        return pts;
      }
    },

    // ТИП 3 (Референс handles\05): Горизонтальная полукапсула на нижнем крае верхнего фасада
    buildFacadeWithHorizontalCapsule(W, H, position = 'bottom_right', slotLength = 210, slotHeight = 42, cornerRadius = 26, segs = 10) {
      const r = Math.min(cornerRadius, slotHeight - 2, slotLength / 2);
      const pts = [{ x: 0, y: H }, { x: W, y: H }];
      if (position === 'bottom_right') {
        const xStart = W - slotLength;
        pts.push({ x: W, y: slotHeight }, { x: xStart + r, y: slotHeight });
        for (let i = 1; i <= segs; i++) {
          const t = (Math.PI / 2) * (i / segs);
          pts.push({ x: (xStart + r) - r * Math.sin(t), y: (slotHeight - r) + r * Math.cos(t) });
        }
        pts.push({ x: xStart, y: 0 }, { x: 0, y: 0 });
      } else {
        const xEnd = slotLength;
        pts.push({ x: W, y: 0 }, { x: xEnd, y: 0 });
        for (let i = 0; i <= segs; i++) {
          const t = (Math.PI / 2) * (i / segs);
          pts.push({ x: (xEnd - r) + r * Math.cos(t), y: (slotHeight - r) + r * Math.sin(t) });
        }
        pts.push({ x: 0, y: slotHeight });
      }
      return pts;
    },

    profiles: {
      cChannelSection(height = 40, depth = 18, rimThickness = 3.5, grooveDepth = 14) {
        return [
          { x: 0, y: 0 },
          { x: depth, y: 0 },
          { x: depth, y: rimThickness },
          { x: depth - grooveDepth, y: rimThickness },
          { x: depth - grooveDepth, y: height - rimThickness },
          { x: depth, y: height - rimThickness },
          { x: depth, y: height },
          { x: 0, y: height },
        ];
      },
      bevel45FacadeSection(facadeHeight = 720, thickness = 18, frontLip = 2.5) {
        const bevel = thickness - frontLip;
        return [
          { x: 0, y: 0 },
          { x: thickness, y: 0 },
          { x: thickness, y: facadeHeight },
          { x: thickness - frontLip, y: facadeHeight },
          { x: 0, y: facadeHeight - bevel },
        ];
      },
    },
  };

  const Engine = {
    THICKNESS: {
      LDSP: 18,
      MDF_FACADE: 18,
      COUNTERTOP_SLIM: 18,
      CARCASS_TO_FACADE_GAP: 2.0,
      FACADE_GAP: 3.0,
      FACADE_EDGE_RADIUS: 2.5,
      SHADOW_GAP: 30.0,
    },

    Handles,

    /**
     * 1. ЧИСТАЯ ПОДРЕЗКА УГЛОВ ПОД БИССЕКТРИСУ (Для коробов штор и ниш на эркерах/углах без торчащих хвостов)
     */
    buildMiteredBandPolygon(chainPtsXY, d0, d1) {
      if (!chainPtsXY || chainPtsXY.length < 2) return [];
      const offsetPolyline = (pts, dist) => {
        const segs = [];
        for (let i = 0; i < pts.length - 1; i++) {
          const [x1, y1] = pts[i];
          const [x2, y2] = pts[i + 1];
          const dx = x2 - x1, dy = y2 - y1;
          const len = Math.hypot(dx, dy) || 1;
          const ux = dx / len, uy = dy / len;
          const nx = -uy, ny = ux;
          segs.push({
            px: x1 + nx * dist,
            py: y1 + ny * dist,
            qx: x2 + nx * dist,
            qy: y2 + ny * dist,
            ux, uy,
          });
        }
        const out = [[segs[0].px, segs[0].py]];
        for (let i = 0; i < segs.length - 1; i++) {
          const L1 = segs[i], L2 = segs[i + 1];
          const det = L1.ux * L2.uy - L1.uy * L2.ux;
          if (Math.abs(det) < 1e-4) {
            out.push([L2.px, L2.py]);
          } else {
            const dx = L2.px - L1.px, dy = L2.py - L1.py;
            const t = (dx * L2.uy - dy * L2.ux) / det;
            out.push([L1.px + t * L1.ux, L1.py + t * L1.uy]);
          }
        }
        const last = segs[segs.length - 1];
        out.push([last.qx, last.qy]);
        return out;
      };
      const lineInner = offsetPolyline(chainPtsXY, d0);
      const lineOuter = offsetPolyline(chainPtsXY, d1);
      return [...lineInner, ...lineOuter.reverse()];
    },

    /**
     * 2. УМНЫЙ СТЕНОВОЙ ФРЕЙМ С 3D-ЭКСТРУЗИЕЙ В 3 ПЛОСКОСТЯХ (Z, Фронт двери, Боковой профиль)
     *    И АВТО-ПРОВЕРКОЙ ВНУТРЕННЕЙ НОРМАЛИ НА КОСЫХ СТЕНАХ (30°/45°/60°)
     *
     * @param {number} x1
     * @param {number} y1
     * @param {number} x2
     * @param {number} y2
     * @param {Array<number>|object} [interiorHintPt] - точка внутри комнаты [cx, cy], чтобы глубина +d гарантированно шла внутрь комнаты!
     */
    createWallFrame(x1, y1, x2, y2, interiorHintPt = null) {
      const w = getTargetWindow();
      const math = w.DiySdk.math;
      const brep = w.HSBrep;
      const toShell = (body) => (body && body.getShells ? body.getShells()[0] : body);

      const dx = x2 - x1, dy = y2 - y1;
      const len = Math.hypot(dx, dy) || 1;
      const ux = dx / len, uy = dy / len;
      let vx = -uy, vy = ux; // по умолчанию CCW нормаль

      // Если передана точка внутри комнаты [cx, cy] — автоматически проверяем, чтобы +d смотрел внутрь комнаты!
      if (interiorHintPt) {
        const cx = Array.isArray(interiorHintPt) ? interiorHintPt[0] : interiorHintPt.x;
        const cy = Array.isArray(interiorHintPt) ? interiorHintPt[1] : interiorHintPt.y;
        const mx = (x1 + x2) * 0.5, my = (y1 + y2) * 0.5;
        const dot = (cx - mx) * vx + (cy - my) * vy;
        if (dot < 0) {
          vx = -vx;
          vy = -vy;
        }
      }

      const pt = (s, d) => [x1 + s * ux + d * vx, y1 + s * uy + d * vy];
      const pt3 = (s, d, z) => new math.Vector3(x1 + s * ux + d * vx, y1 + s * uy + d * vy, z);

      const makeLoop2D = (pts2D, wantCCW = true) => {
        let area2 = 0;
        for (let i = 0; i < pts2D.length; i++) {
          const pA = pts2D[i], pB = pts2D[(i + 1) % pts2D.length];
          const ax = Array.isArray(pA) ? pA[0] : pA.x;
          const ay = Array.isArray(pA) ? pA[1] : pA.y;
          const bx = Array.isArray(pB) ? pB[0] : pB.x;
          const by = Array.isArray(pB) ? pB[1] : pB.y;
          area2 += (ax * by - bx * ay);
        }
        const isCCW = area2 >= 0;
        const ordered = (isCCW === wantCCW) ? pts2D : pts2D.slice().reverse();
        return new math.Loop(ordered.map(p => new math.Vector2(
          Array.isArray(p) ? p[0] : p.x,
          Array.isArray(p) ? p[1] : p.y
        )));
      };

      // А. Вертикальная экструзия (план сверху XY -> по оси Z от z0 до z1)
      const extrudeXY = (outerPtsXY, z0, z1, holesPtsArray = []) => {
        const minZ = Math.min(z0, z1), maxZ = Math.max(z0, z1);
        if (maxZ - minZ < 0.5 || !outerPtsXY || outerPtsXY.length < 3) return null;
        const loops = [makeLoop2D(outerPtsXY, true)];
        for (const h of (holesPtsArray || [])) {
          if (h && h.length >= 3) loops.push(makeLoop2D(h, false));
        }
        const poly = new math.Polygon(loops);
        const coord = new math.Coordinate3(new math.Vector3(0, 0, minZ), math.Vector3.Z());
        return toShell(brep.alg.BodyBuilder.extrude(coord, poly, math.Vector3.Z(), 0, maxZ - minZ));
      };

      // Б. Фронтальная экструзия (фасадная развёртка [s, z] -> вглубь от d0 до d1)
      // Позволяет строить ЛЮБОЙ контур дверцы с вырезом под ручку ОДНОЙ ЦЕЛЬНОЙ ДЕТАЛЬЮ без швов!
      const frontPoly = (outerPtsSZ, d0, d1, dec, holesPtsSZ = []) => {
        const da = Math.min(d0, d1), db = Math.max(d0, d1);
        if (db - da < 0.5 || !outerPtsSZ || outerPtsSZ.length < 3) return null;
        const origin = pt3(0, da, 0);
        const dirU = new math.Vector3(ux, uy, 0);
        const dirZ = new math.Vector3(0, 0, 1);
        const dirNormal = dirU.cross(dirZ);
        const extDir = new math.Vector3(vx, vy, 0);
        const coord = new math.Coordinate3(origin, dirU, dirZ);
        const loops = [makeLoop2D(outerPtsSZ, true)];
        for (const h of (holesPtsSZ || [])) {
          if (h && h.length >= 3) loops.push(makeLoop2D(h, false));
        }
        const poly = new math.Polygon(loops);
        const sh = toShell(brep.alg.BodyBuilder.extrude(coord, poly, extDir, 0, db - da));
        return sh ? { sh, dec } : null;
      };

      // В. Боковая профильная экструзия (сечение [d, z] -> вдоль стены от s0 до s1)
      // Позволяет строить ИДЕАЛЬНО ГЛАДКОЕ скошенное дно раковины (0 ступенек!), скос 45° J-профиля и верхние профильные ручки!
      const sidePoly = (outerPtsDZ, s0, s1, dec, holesPtsDZ = []) => {
        const sa = Math.min(s0, s1), sb = Math.max(s0, s1);
        if (sb - sa < 0.5 || !outerPtsDZ || outerPtsDZ.length < 3) return null;
        const origin = pt3(sa, 0, 0);
        const dirV = new math.Vector3(vx, vy, 0);
        const dirZ = new math.Vector3(0, 0, 1);
        const extDir = new math.Vector3(ux, uy, 0);
        const coord = new math.Coordinate3(origin, dirV, dirZ);
        const loops = [makeLoop2D(outerPtsDZ, true)];
        for (const h of (holesPtsDZ || [])) {
          if (h && h.length >= 3) loops.push(makeLoop2D(h, false));
        }
        const poly = new math.Polygon(loops);
        const sh = toShell(brep.alg.BodyBuilder.extrude(coord, poly, extDir, 0, sb - sa));
        return sh ? { sh, dec } : null;
      };

      const box = (s0, s1, d0, d1, z0, z1, dec) => {
        const sa = Math.min(s0, s1), sb = Math.max(s0, s1);
        const da = Math.min(d0, d1), db = Math.max(d0, d1);
        if (sb - sa < 0.5 || db - da < 0.5 || Math.abs(z1 - z0) < 0.5) return null;
        const sh = extrudeXY([pt(sa, da), pt(sb, da), pt(sb, db), pt(sa, db)], z0, z1);
        return sh ? { sh, dec } : null;
      };

      const poly = (outerSD, z0, z1, dec, holesSD = []) => {
        const outerXY = outerSD.map(p => Array.isArray(p) ? pt(p[0], p[1]) : pt(p.x, p.y));
        const holesXY = (holesSD || []).map(h => h.map(p => Array.isArray(p) ? pt(p[0], p[1]) : pt(p.x, p.y)));
        const sh = extrudeXY(outerXY, z0, z1, holesXY);
        return sh ? { sh, dec } : null;
      };

      const roundedFacade = (s0, s1, dBack, dFront, z0, z1, dec, r = 2.5) => {
        const sa = Math.min(s0, s1), sb = Math.max(s0, s1);
        const da = Math.min(dBack, dFront), db = Math.max(dBack, dFront);
        if (sb - sa < 6 || db - da < 4 || Math.abs(z1 - z0) < 6) return null;
        const c = Math.min(r, (db - da) * 0.25);
        const pts = [
          pt(sa + c, da), pt(sb - c, da), pt(sb, da + c), pt(sb, db - c),
          pt(sb - c, db), pt(sa + c, db), pt(sa, db - c), pt(sa, da + c),
        ];
        const sh = extrudeXY(pts, z0, z1);
        return sh ? { sh, dec } : null;
      };

      // Г. Бесшовная прямоугольная рамка (для витрин, молдингов, рамок ТВ и зеркал) ЕДИНЫМ полигоном с вырезом (0 линий стыка на углах!)
      const hollowFrame = (s0, s1, z0, z1, frameWidth, d0, d1, dec) => {
        const sa = Math.min(s0, s1), sb = Math.max(s0, s1);
        const za = Math.min(z0, z1), zb = Math.max(z0, z1);
        const fw = Math.max(1, frameWidth || 18);
        if (sb - sa <= 2 * fw + 2 || zb - za <= 2 * fw + 2) {
          return box(sa, sb, d0, d1, za, zb, dec);
        }
        const outer = [[sa, za], [sb, za], [sb, zb], [sa, zb]];
        const hole  = [[sa + fw, za + fw], [sb - fw, za + fw], [sb - fw, zb - fw], [sa + fw, zb - fw]];
        return frontPoly(outer, d0, d1, dec, [hole]);
      };

      return {
        x1, y1, x2, y2, len, ux, uy, vx, vy,
        pt, pt3, extrudeXY, box, poly, frontPoly, sidePoly, roundedFacade, hollowFrame,
        facade: roundedFacade,
      };
    },

    /**
     * 2.5 БЫСТРАЯ ИНИЦИАЛИЗАЦИЯ DIY-ДОКУМЕНТА («Моделирование интерьера») В 1 СТРОЧКУ
     *     Гарантирует, что даже в пустом проекте Homestyler агент за 0.1 сек получит { app, fp, pm0, doc, docUUID }
     */
    async ensureDiyDoc() {
      const w = getTargetWindow();
      const app = w.HSApp.App.getApp();
      const fp = app.floorplan;
      const dm = w.DiySdk.DmDiyApi;
      let pm0 = fp.scene.getCustomizedPms()[0];
      if (!pm0) {
        const newDocStr = dm.createDocument();
        pm0 = w.HSApp.Util.CustomizedPMModel.createCustomizedPMModel({
          webCADDocument: newDocStr,
          creator: (w.adskUser && w.adskUser.uid) ? w.adskUser.uid : '',
          unit: 'mm',
        });
        fp.scene.addChild(pm0);
      }
      if (pm0.openDiyDocument) await pm0.openDiyDocument();
      const docUUID = pm0.modelingDocId;
      let docMap = null;
      const origGet = Map.prototype.get;
      Map.prototype.get = function (k) {
        if (k === '__hsj_capture__') docMap = this;
        return origGet.call(this, k);
      };
      try { dm.existDocument('__hsj_capture__'); } finally { Map.prototype.get = origGet; }
      const doc = docMap ? docMap.get(docUUID) : null;
      return { app, fp, dm, pm0, doc, docUUID };
    },

    /**
     * 3. РЕАЛЬНЫЙ КОРПУС ИЗ ЛИСТОВ ЛДСП 18 ММ (С ПЕРЕДНИМ И БОКОВЫМИ ЦОКОЛЯМИ БЕЗ ДЫРОК СБОКУ!)
     */
    buildRealCarcass(frame, s0, s1, depthCarcass, z0, z1, dec, opts = {}) {
      const t = opts.thick || 18;
      const plinthH = opts.plinthH !== undefined ? opts.plinthH : (z0 === 0 ? 60 : 0);
      const plinthInset = opts.plinthInset !== undefined ? opts.plinthInset : 25;
      const zBot = z0 + plinthH;
      const parts = [
        frame.box(s0, s0 + t, 0, depthCarcass, zBot, z1, dec),
        frame.box(s1 - t, s1, 0, depthCarcass, zBot, z1, dec),
        frame.box(s0 + t, s1 - t, 0, depthCarcass, zBot, zBot + t, dec),
        frame.box(s0 + t, s1 - t, 0, depthCarcass, z1 - t, z1, dec),
        frame.box(s0 + t, s1 - t, 0, 16, zBot + t, z1 - t, dec),
      ];
      if (plinthH > 0) {
        const dPlinthFront = Math.max(t + 10, depthCarcass - plinthInset);
        // Передняя планка цоколя на всю ширину s0..s1
        parts.push(frame.box(s0, s1, dPlinthFront - t, dPlinthFront, z0, zBot, dec));
        // Боковые планки цоколя (чтобы на открытых боковинах шкафов/витрин никогда не было дырки под боковиной!)
        if (opts.sidePlinthLeft !== false) {
          parts.push(frame.box(s0, s0 + t, 0, dPlinthFront - t, z0, zBot, dec));
        }
        if (opts.sidePlinthRight !== false) {
          parts.push(frame.box(s1 - t, s1, 0, dPlinthFront - t, z0, zBot, dec));
        }
      }
      return parts.filter(Boolean);
    },

    /**
     * 4. МДФ-ФАСАД С ОТСТУПОМ 2 ММ ОТ КОРПУСА И РУЧКОЙ:
     *    ВАЖНОЕ РАЗДЕЛЕНИЕ ТИПОВ РУЧЕК:
     *    А) ПРОСТЫЕ ИНТЕГРИРОВАННЫЕ ПРОФИЛЬНЫЕ РУЧКИ НА ВСЮ ВЫСОТУ ИЛИ ВСЮ ШИРИНУ ФАСАДА (ПО УМОЛЧАНИЮ!):
     *       - type: 'vert_profile' (или side: 'left'|'right' без указания фигурного типа) — простая интегрированная
     *         ручка из профиля (Г/С-профиль 3ddd, референс handles\06 и 02) СТРОГО НА ВСЮ ВЫСОТУ ФАСАДА (z0..z1) без фигурных вырезов!
     *       - type: 'top_profile' (или side: 'top') — простая интегрированная ручка из профиля СТРОГО НА ВСЮ ШИРИНУ ФАСАДА (s0..s1) сверху!
     *       - type: 'bottom_profile' (или side: 'bottom') — простая интегрированная ручка из профиля НА ВСЮ ШИРИНУ ФАСАДА снизу!
     *       - type: 'bevel45_top' (референс handles\03) — скос торца под 45° (J-профиль) + Gola на всю ширину фасада.
     *    Б) ФИГУРНЫЕ ВРЕЗНЫЕ РУЧКИ (вызывать ТОЛЬКО когда явно нужны фигурные выемки в части фасада!):
     *       - type: 'shaped_chamfer' (референсы handles\01 и 04) — ФИГУРНАЯ врезная ручка с локальной выемкой и скосами 45°.
     *       - type: 'arc' / 'capsule_v' (референс handles\01) — ФИГУРНАЯ круглая/капсульная выемка.
     *       - type: 'capsule_h' (референс handles\05) — ФИГУРНАЯ горизонтальная капсула со шпоном.
     */
    buildMdfFacadeWithHandle(frame, s0, s1, dCarcassFront, z0, z1, decFacade, handleCfg = null) {
      const gap = 2.0;
      const thick = 18.0;
      const dBack = dCarcassFront + gap;
      const dFront = dBack + thick;
      const W = s1 - s0;
      const H = z1 - z0;
      const facadeParts = [];
      const handleParts = [];

      if (!handleCfg) {
        facadeParts.push(frame.roundedFacade(s0, s1, dBack, dFront, z0, z1, decFacade, 2.5));
        return { facadeParts: facadeParts.filter(Boolean), handleParts: [] };
      }

      const side = handleCfg.side || 'right';
      const hType = handleCfg.type || (side === 'top' ? 'top_profile' : (side === 'bottom' ? 'bottom_profile' : 'vert_profile'));
      const decH = handleCfg.decHandle || decFacade;
      const profW = handleCfg.profileWidth || 20;

      if (hType === 'vert_profile') {
        // ПРОСТАЯ ИНТЕГРИРОВАННАЯ ПРОФИЛЬНАЯ РУЧКА НА ВСЮ ВЫСОТУ ФАСАДА (z0 .. z1)
        if (side === 'right') {
          facadeParts.push(frame.roundedFacade(s0, s1 - profW, dBack, dFront, z0, z1, decFacade, 2.5));
          // 1. Утопленная задняя планка профиля (паз глубиной 13 мм под пальцы на всю высоту фасада z0..z1)
          handleParts.push(frame.box(s1 - profW, s1, dBack, dBack + 5, z0, z1, decH));
          // 2. Торцевая полка профиля на стыке с МДФ-фасадом (dBack..dFront)
          handleParts.push(frame.box(s1 - profW, s1 - profW + 2.5, dBack, dFront, z0, z1, decH));
          // 3. Передний кантик-захват профиля (нависает на 6 мм под пальцы на всю высоту z0..z1)
          handleParts.push(frame.box(s1 - profW, s1 - profW + 6.5, dFront - 2.5, dFront, z0, z1, decH));
        } else {
          facadeParts.push(frame.roundedFacade(s0 + profW, s1, dBack, dFront, z0, z1, decFacade, 2.5));
          // 1. Утопленная задняя планка профиля (паз глубиной 13 мм под пальцы на всю высоту фасада z0..z1)
          handleParts.push(frame.box(s0, s0 + profW, dBack, dBack + 5, z0, z1, decH));
          // 2. Торцевая полка профиля на стыке с МДФ-фасадом (dBack..dFront)
          handleParts.push(frame.box(s0 + profW - 2.5, s0 + profW, dBack, dFront, z0, z1, decH));
          // 3. Передний кантик-захват профиля (нависает на 6 мм под пальцы на всю высоту z0..z1)
          handleParts.push(frame.box(s0 + profW - 6.5, s0 + profW, dFront - 2.5, dFront, z0, z1, decH));
        }
      } else if (hType === 'top_profile' || side === 'top') {
        // ПРОСТАЯ ИНТЕГРИРОВАННАЯ ПРОФИЛЬНАЯ РУЧКА НА ВСЮ ШИРИНУ ФАСАДА СВЕРХУ (s0 .. s1)
        facadeParts.push(frame.roundedFacade(s0, s1, dBack, dFront, z0, z1 - profW, decFacade, 2.5));
        handleParts.push(frame.box(s0, s1, dBack, dBack + 5, z1 - profW, z1 - 2.5, decH));
        handleParts.push(frame.box(s0, s1, dBack, dFront, z1 - 2.5, z1, decH));
        handleParts.push(frame.box(s0, s1, dFront - 2.5, dFront, z1 - 7.5, z1 - 2.5, decH));
      } else if (hType === 'bottom_profile' || side === 'bottom') {
        // ПРОСТАЯ ИНТЕГРИРОВАННАЯ ПРОФИЛЬНАЯ РУЧКА НА ВСЮ ШИРИНУ ФАСАДА СНИЗУ (s0 .. s1)
        facadeParts.push(frame.roundedFacade(s0, s1, dBack, dFront, z0 + profW, z1, decFacade, 2.5));
        handleParts.push(frame.box(s0, s1, dBack, dBack + 5, z0 + 2.5, z0 + profW, decH));
        handleParts.push(frame.box(s0, s1, dBack, dFront, z0, z0 + 2.5, decH));
        handleParts.push(frame.box(s0, s1, dFront - 2.5, dFront, z0 + 2.5, z0 + 7.5, decH));
      } else if ((hType === 'shaped_chamfer' || hType === 'chamfer') && frame.frontPoly) {
        // ФИГУРНАЯ врезная ручка со скосами 45° (использовать ТОЛЬКО когда явно запрошена фигурная ручка!)
        const yBot = handleCfg.yBottom !== undefined ? handleCfg.yBottom : 0;
        const yTop = handleCfg.yTop !== undefined ? handleCfg.yTop : H;
        const cutW = handleCfg.width || 20;
        const cham = handleCfg.chamfer !== undefined ? handleCfg.chamfer : 28;
        const localPts = Handles.buildFacadeWithChamferSlot(W, H, side, yBot, yTop, cutW, cham);
        const worldSZ = localPts.map(p => [s0 + p.x, z0 + p.y]);
        facadeParts.push(frame.frontPoly(worldSZ, dBack, dFront, decFacade));
        if (side === 'right') {
          handleParts.push(frame.box(s1 - cutW - 14, s1 + 2, dBack - 2, dBack + 6, z0 + Math.max(0, yBot - cham), z0 + Math.min(H, yTop + cham), decH));
        } else {
          handleParts.push(frame.box(s0 - 2, s0 + cutW + 14, dBack - 2, dBack + 6, z0 + Math.max(0, yBot - cham), z0 + Math.min(H, yTop + cham), decH));
        }
      } else if ((hType === 'arc' || hType === 'capsule_v') && frame.frontPoly) {
        const side = handleCfg.side || 'right';
        const yCenter = handleCfg.yCenter !== undefined ? handleCfg.yCenter : H * 0.5;
        const radius = handleCfg.radius || 65;
        const straightH = handleCfg.straightHeight || (hType === 'capsule_v' ? 140 : 0);
        const localPts = Handles.buildFacadeWithArcOrCapsuleSlot(W, H, side, yCenter, radius, straightH, 16);
        const worldSZ = localPts.map(p => [s0 + p.x, z0 + p.y]);
        facadeParts.push(frame.frontPoly(worldSZ, dBack, dFront, decFacade));
        const padH = radius + straightH * 0.5 + 15;
        if (side === 'right') {
          handleParts.push(frame.box(s1 - radius - 12, s1 + 2, dBack - 2, dBack + 6, z0 + yCenter - padH, z0 + yCenter + padH, decH));
        } else {
          handleParts.push(frame.box(s0 - 2, s0 + radius + 12, dBack - 2, dBack + 6, z0 + yCenter - padH, z0 + yCenter + padH, decH));
        }
      } else if (hType === 'capsule_h' && frame.frontPoly) {
        const pos = handleCfg.position || (handleCfg.side === 'left' ? 'bottom_left' : 'bottom_right');
        const slotL = handleCfg.slotLength || 210;
        const slotH = handleCfg.slotHeight || 42;
        const localPts = Handles.buildFacadeWithHorizontalCapsule(W, H, pos, slotL, slotH, 26, 12);
        const worldSZ = localPts.map(p => [s0 + p.x, z0 + p.y]);
        facadeParts.push(frame.frontPoly(worldSZ, dBack, dFront, decFacade));
        const hs0 = pos === 'bottom_right' ? (s1 - slotL - 12) : s0;
        const hs1 = pos === 'bottom_right' ? s1 : (s0 + slotL + 12);
        handleParts.push(frame.box(hs0, hs1, dBack - 2, dBack + 6, z0, z0 + slotH + 12, decH));
      } else if (hType === 'bevel45_top' && frame.sidePoly) {
        // Референс handles\03: J-профиль со скосом 45° внутрь по верхнему торцу + Gola
        const sec = Handles.profiles.bevel45FacadeSection(H, thick, 2.5);
        const worldDZ = sec.map(p => [dBack + p.x, z0 + p.y]);
        facadeParts.push(frame.sidePoly(worldDZ, s0, s1, decFacade));
        handleParts.push(frame.box(s0, s1, dBack - 14, dBack, z1 - 38, z1 + 4, decH));
      } else if (hType === 'top_profile' || handleCfg.side === 'top') {
        // Референс handles\06: Верхний торцевой Г/С-профиль 3ddd
        facadeParts.push(frame.roundedFacade(s0, s1, dBack, dFront, z0, z1 - 22, decFacade, 2.5));
        handleParts.push(frame.box(s0, s1, dBack, dBack + 5, z1 - 22, z1 - 2.5, decH));
        handleParts.push(frame.box(s0, s1, dBack, dFront, z1 - 2.5, z1, decH));
        handleParts.push(frame.box(s0, s1, dFront - 2.5, dFront, z1 - 8, z1 - 2.5, decH));
      } else {
        facadeParts.push(frame.roundedFacade(s0, s1, dBack, dFront, z0, z1, decFacade, 2.5));
      }

      return {
        facadeParts: facadeParts.filter(Boolean),
        handleParts: handleParts.filter(Boolean),
      };
    },

    /**
     * 5. КЛАССИЧЕСКАЯ И НЕОКЛАССИЧЕСКАЯ СТУПЕНЧАТАЯ ФРЕЗЕРОВКА ФАСАДОВ С ФИЛЁНКОЙ
     *    (Референсы facades\01..03: единые ступенчатые контуры без угловых перекрестий!)
     */
    buildClassicMilledFacade(frame, s0, s1, dCarcassFront, z0, z1, dec, style = 'classic_2step') {
      const gap = 2.0;
      const dBack = dCarcassFront + gap;
      const baseThick = 12.0;
      const parts = [];

      parts.push(frame.roundedFacade(s0, s1, dBack, dBack + baseThick, z0, z1, dec, 2.0));

      const addRing = (mOut, mIn, dA, dB) => {
        if ((s1 - s0) <= 2 * mIn + 20 || (z1 - z0) <= 2 * mIn + 20) return;
        if (frame.frontPoly) {
          const outer = [
            [s0 + mOut, z0 + mOut],
            [s1 - mOut, z0 + mOut],
            [s1 - mOut, z1 - mOut],
            [s0 + mOut, z1 - mOut],
          ];
          const hole = [
            [s0 + mIn, z0 + mIn],
            [s1 - mIn, z0 + mIn],
            [s1 - mIn, z1 - mIn],
            [s0 + mIn, z1 - mIn],
          ];
          parts.push(frame.frontPoly(outer, dA, dB, dec, [hole]));
        } else {
          parts.push(frame.box(s0 + mOut, s1 - mOut, dA, dB, z0 + mOut, z0 + mIn, dec));
          parts.push(frame.box(s0 + mOut, s1 - mOut, dA, dB, z1 - mIn, z1 - mOut, dec));
          parts.push(frame.box(s0 + mOut, s0 + mIn, dA, dB, z0 + mIn, z1 - mIn, dec));
          parts.push(frame.box(s1 - mIn, s1 - mOut, dA, dB, z0 + mIn, z1 - mIn, dec));
        }
      };

      if (style === 'neoclassic_1step') {
        const frameW = 50, grooveW = 34;
        const islandInset = frameW + grooveW;
        addRing(1.5, frameW, dBack + baseThick, dBack + 18);
        if ((s1 - s0) > 2 * islandInset + 30 && (z1 - z0) > 2 * islandInset + 30) {
          parts.push(frame.roundedFacade(s0 + islandInset, s1 - islandInset, dBack + baseThick, dBack + 16.5, z0 + islandInset, z1 - islandInset, dec, 1.5));
        }
      } else {
        addRing(1.5, 48, dBack + baseThick, dBack + 20);
        addRing(48,  58, dBack + baseThick, dBack + 17);
        if (style === 'classic_3step') {
          addRing(58, 65, dBack + baseThick, dBack + 14.5);
        }
        const islandOuter = style === 'classic_3step' ? 82 : 76;
        const islandInner = islandOuter + 9;
        if ((s1 - s0) > 2 * islandInner + 30 && (z1 - z0) > 2 * islandInner + 30) {
          parts.push(frame.roundedFacade(s0 + islandOuter, s1 - islandOuter, dBack + baseThick, dBack + 15.5, z0 + islandOuter, z1 - islandOuter, dec, 1.5));
          parts.push(frame.roundedFacade(s0 + islandInner, s1 - islandInner, dBack + 15.5, dBack + 18.5, z0 + islandInner, z1 - islandInner, dec, 1.5));
        }
      }
      return parts.filter(Boolean);
    },

    /**
     * 6. РАКОВИНА ИЗ КЕРАМОГРАНИТА СО СКОШЕННЫМ ДНОМ (100% ГЛАДКАЯ НАКЛОННАЯ ПЛИТА БЕЗ СТУПЕНЕК!)
     *    И ЩЕЛЕВЫМ ЛОТКОМ ДЛЯ СЛИВА У ЗАДНЕЙ СТЕНКИ (Референс sinks\01_porcelain_sloped_slot_drain_sink.jpg)
     */
    buildPorcelainSlopedDrainSink(frame, extrudePolyZ, sStart, sEnd, depthTotal, zTop, sinkS0, sinkS1, decStone, opts = {}) {
      const apronH = opts.apronH || 110;
      const topThick = opts.topThick || 18;
      const sinkD0 = opts.sinkD0 || 85;
      const sinkD1 = opts.sinkD1 || (depthTotal - 75);
      const slotW  = opts.slotW  || 40;
      const parts = [];

      const extXY = extrudePolyZ || frame.extrudeXY;

      // 1. Верхняя плита столешницы с единым прямоугольным вырезом (hole) под раковину — 0 швов!
      const outerXY = [
        frame.pt(sStart, 0),
        frame.pt(sEnd, 0),
        frame.pt(sEnd, depthTotal),
        frame.pt(sStart, depthTotal),
      ];
      const holeXY = [
        frame.pt(sinkS0, sinkD0),
        frame.pt(sinkS1, sinkD0),
        frame.pt(sinkS1, sinkD1),
        frame.pt(sinkS0, sinkD1),
      ];
      const topSh = extXY(outerXY, zTop - topThick, zTop, [holeXY]);
      if (topSh) parts.push({ sh: topSh, dec: decStone });

      // 2. Передняя и боковые каменные юбки-фартуки столешницы (apronH = 110 мм)
      parts.push(frame.box(sStart, sEnd, depthTotal - topThick, depthTotal, zTop - apronH, zTop - topThick, decStone));
      parts.push(frame.box(sStart, sStart + topThick, 0, depthTotal - topThick, zTop - apronH, zTop - topThick, decStone));
      parts.push(frame.box(sEnd - topThick, sEnd, 0, depthTotal - topThick, zTop - apronH, zTop - topThick, decStone));

      // 3. Внутренние вертикальные стенки чаши и дно щелевого лотка слива (Z = zTop - 135 .. zTop - topThick)
      const zBasinBot = zTop - 135;
      parts.push(frame.box(sinkS0 - 16, sinkS0, sinkD0 - 16, sinkD1 + 16, zBasinBot, zTop - topThick, decStone));
      parts.push(frame.box(sinkS1, sinkS1 + 16, sinkD0 - 16, sinkD1 + 16, zBasinBot, zTop - topThick, decStone));
      parts.push(frame.box(sinkS0, sinkS1, sinkD0 - 16, sinkD0, zBasinBot, zTop - topThick, decStone));
      parts.push(frame.box(sinkS0, sinkS1, sinkD1, sinkD1 + 16, zBasinBot, zTop - topThick, decStone));
      parts.push(frame.box(sinkS0, sinkS1, sinkD0, sinkD1, zBasinBot - 14, zBasinBot, decStone));

      // 4. ИДЕАЛЬНО ГЛАДКОЕ СКОШЕННОЕ ДНО РАКОВИНЫ (Sloped Bottom Ramp) + ЛОТОК СЛИВА 40 ММ у задней стенки!
      // Строится ОДНИМ боковым полигоном (sidePoly) без единой ступеньки!
      const dRampRear = sinkD0 + slotW;
      const dRampFront = sinkD1;
      const zRampRear = zTop - 110;
      const zRampFront = zTop - 64;
      const slabThick = 16;

      if (frame.sidePoly) {
        const rampSectionDZ = [
          [dRampRear,  zRampRear - slabThick],
          [dRampFront, zRampFront - slabThick],
          [dRampFront, zRampFront],
          [dRampRear,  zRampRear],
        ];
        parts.push(frame.sidePoly(rampSectionDZ, sinkS0 + 0.5, sinkS1 - 0.5, decStone));
      } else {
        // Fallback, если используется старый кастомный frame без sidePoly: создаём Coordinate3 напрямую
        const w = getTargetWindow();
        const math = w.DiySdk.math;
        const brep = w.HSBrep;
        const toShell = (body) => (body && body.getShells ? body.getShells()[0] : body);
        const p0 = frame.pt(sinkS0 + 0.5, 0);
        const p1 = frame.pt(sinkS1 - 0.5, 0);
        const pD = frame.pt(sinkS0 + 0.5, 100);
        const ux = (p1[0] - p0[0]) / Math.hypot(p1[0] - p0[0], p1[1] - p0[1]);
        const uy = (p1[1] - p0[1]) / Math.hypot(p1[0] - p0[0], p1[1] - p0[1]);
        const vx = (pD[0] - p0[0]) / 100;
        const vy = (pD[1] - p0[1]) / 100;
        const coord = new math.Coordinate3(
          new math.Vector3(p0[0], p0[1], 0),
          new math.Vector3(vx, vy, 0),
          new math.Vector3(0, 0, 1)
        );
        const loop = new math.Loop([
          new math.Vector2(dRampRear,  zRampRear - slabThick),
          new math.Vector2(dRampFront, zRampFront - slabThick),
          new math.Vector2(dRampFront, zRampFront),
          new math.Vector2(dRampRear,  zRampRear),
        ]);
        const poly = new math.Polygon([loop]);
        const sh = toShell(brep.alg.BodyBuilder.extrude(coord, poly, new math.Vector3(ux, uy, 0), 0, (sinkS1 - sinkS0) - 1.0));
        if (sh) parts.push({ sh, dec: decStone });
      }

      return parts.filter(Boolean);
    },

    /**
     * 7. ВНУТРЕННЯЯ ИЛИ РАЗДЕЛИТЕЛЬНАЯ ПОЛКА КОРПУСА (СТРОГО МЕЖДУ БОКОВИНАМИ s0+18..s1-18 И СТРОГО ВРОВЕНЬ С КОРПУСОМ 0..depthCarcass!)
     *    Исключает ошибку, когда полка оказывается короче боковин или прорезает боковины/фасады!
     */
    buildInternalShelf(frame, s0, s1, depthCarcass, zShelfBottom, dec, opts = {}) {
      const t = opts.thick || 18;
      const dStart = opts.dStart !== undefined ? opts.dStart : 0;
      const dEnd = depthCarcass - (opts.recessFront || 0);
      return frame.box(s0 + t, s1 - t, dStart, dEnd, zShelfBottom, zShelfBottom + t, dec);
    },

    /**
     * 8. НАСТОЯЩИЕ НАКЛАДНЫЕ РАСПАШНЫЕ ФАСАДЫ (1 ИЛИ 2 СТВОРКИ) ПОВЕРХ КОРПУСА (d = depthCarcass + 2 .. depthCarcass + 20)
     *    Гарантирует:
     *    - Фасады НИКОГДА не утапливаются внутрь боковин и НИКОГДА не врезаются в полки или боковины!
     *    - Перекрывают торцы боковин, дна и крышки с правильным техническим отступом 2 мм по периметру и зазором 3 мм между дверками.
     *    - На верхних шкафах, антресолях и шкафчиках санузла по умолчанию БЕЗ РУЧЕК (handleType: 'none', push-to-open).
     */
    buildOverlayDoors(frame, s0, s1, depthCarcass, z0, z1, decFacade, opts = {}) {
      const count = opts.doors || ((s1 - s0) > 620 ? 2 : 1);
      const margin = opts.margin !== undefined ? opts.margin : 2.0;
      const centerGap = opts.centerGap !== undefined ? opts.centerGap : 3.0;
      const bottomOverhang = opts.bottomOverhang || 0;
      const milledStyle = opts.milledStyle || null; // 'neoclassic_1step' | 'classic_2step' | 'classic_3step' | null
      const handleType = opts.handleType || 'none'; // 'none' | 'vert_profile' | 'top_profile' | 'long_bar'
      const decHandle = opts.decHandle || decFacade;

      const za = z0 + margin - bottomOverhang;
      const zb = z1 - margin;
      const dBack = depthCarcass + 2.0;
      const dFront = dBack + 18.0;

      const facadeParts = [];
      const handleParts = [];

      const spans = count === 1
        ? [[s0 + margin, s1 - margin, opts.hingeSide === 'right' ? 'left' : 'right']]
        : [
            [s0 + margin, (s0 + s1) * 0.5 - centerGap * 0.5, 'right'],
            [(s0 + s1) * 0.5 + centerGap * 0.5, s1 - margin, 'left'],
          ];

      for (const [daS0, daS1, handleSide] of spans) {
        if (milledStyle) {
          facadeParts.push(...this.buildClassicMilledFacade(frame, daS0, daS1, depthCarcass, za, zb, decFacade, milledStyle));
        } else if (handleType === 'vert_profile' || handleType === 'top_profile' || handleType === 'bevel45_top') {
          const res = this.buildMdfFacadeWithHandle(frame, daS0, daS1, depthCarcass, za, zb, decFacade, {
            type: handleType,
            side: handleType === 'top_profile' ? 'top' : handleSide,
            decHandle,
          });
          facadeParts.push(...res.facadeParts);
          handleParts.push(...res.handleParts);
        } else {
          facadeParts.push(frame.roundedFacade(daS0, daS1, dBack, dFront, za, zb, decFacade, 2.5));
        }

        // Если явно запрошены длинные трубчатые накладные ручки на 2 ножках (например, в проекте 0599):
        if (handleType === 'long_bar') {
          const barLen = opts.barLength || Math.min(500, Math.max(320, (zb - za) * 0.32));
          const barZ0 = opts.barZ0 !== undefined ? opts.barZ0 : (za + 120);
          const barZ1 = Math.min(zb - 60, barZ0 + barLen);
          const edgeOffset = opts.barEdgeOffset || 38;
          const hs = handleSide === 'right' ? (daS1 - edgeOffset) : (daS0 + edgeOffset);
          const rBar = 6;
          // 2 ножки-стойки + длинная вертикальная трубка с выступающими кончиками (35 мм за ножки)
          handleParts.push(frame.box(hs - 4.5, hs + 4.5, dFront, dFront + 22, barZ0 + 35, barZ0 + 47, decHandle));
          handleParts.push(frame.box(hs - 4.5, hs + 4.5, dFront, dFront + 22, barZ1 - 47, barZ1 - 35, decHandle));
          handleParts.push(frame.box(hs - rBar, hs + rBar, dFront + 20, dFront + 32, barZ0, barZ1, decHandle));
        }
      }

      return {
        facadeParts: facadeParts.filter(Boolean),
        handleParts: handleParts.filter(Boolean),
      };
    },

    /**
     * 9. ЭТАЛОННЫЙ МЕБЕЛЬНЫЙ ПЕНАЛ ПОД КОЛОННУ СМ + СШМ ДО ПОТОЛКА (БЕЗ УТОПЛЕННЫХ ПОЛОК И БЕЗ НАЕЗДА ФАСАДОВ!)
     *    - Внизу (z = 0 .. 870) открытая ниша под СМ СТРОГО БЕЗ НИЖНЕГО ЦОКОЛЯ (стиральная машина стоит на полу).
     *    - Между СМ и СШМ (z = 870 .. 920) разделительная полка и выдвижная полка для белья СТРОГО ВРОВЕНЬ С КОРПУСОМ (d = 0..depthCarcass, без торчащих ручек!).
     *    - Выше (z = 920 .. 1790) открытая ниша под СШМ.
     *    - Сверху (z = 1790 .. zCeiling) шкаф с полками и НАКЛАДНЫМИ ФАСАДАМИ (d = depthCarcass+2 .. depthCarcass+20) СТРОГО БЕЗ РУЧЕК (push-to-open),
     *      которые полностью перекрывают горизонтальную полку z=1790..1808 и крышку без малейших пересечений!
     */
    buildLaundryColumn(frame, s0, s1, totalDepth, zCeiling, decCarcass, decFacade, opts = {}) {
      const t = opts.thick || 18;
      const depthCarcass = totalDepth - 20; // 2 мм зазор + 18 мм накладной фасад = ровно totalDepth!
      const zWasherTop = opts.zWasherTop || 870;
      const pulloutH = opts.pulloutH || 50;
      const zDryerBot = zWasherTop + pulloutH;
      const zUpperBot = opts.zUpperBot || 1790;

      const carcassParts = [
        // Левая и правая цельные боковины от пола до чистового потолка (строго 0 .. depthCarcass)
        frame.box(s0, s0 + t, 0, depthCarcass, 0, zCeiling, decCarcass),
        frame.box(s1 - t, s1, 0, depthCarcass, 0, zCeiling, decCarcass),
        // Нижняя полка над стиральной машиной (z = 870 .. 888) строго вровень с боковинами (0 .. depthCarcass)
        frame.box(s0 + t, s1 - t, 0, depthCarcass, zWasherTop, zWasherTop + t, decCarcass),
        // Выдвижная полка под корзину для белья со скрытым вырезом-захватом заподлицо с корпусом (НИКАКИХ коротких ручек!)
        frame.box(s0 + t + 2, s1 - t - 2, 0, depthCarcass, zWasherTop + t + 2, zDryerBot - t, decFacade || decCarcass),
        // Полка под сушильной машиной (z = 902 .. 920) строго вровень с боковинами
        frame.box(s0 + t, s1 - t, 0, depthCarcass, zDryerBot - t, zDryerBot, decCarcass),
        // Дно верхнего шкафа над сушильной машиной (z = 1790 .. 1808) строго 0 .. depthCarcass
        frame.box(s0 + t, s1 - t, 0, depthCarcass, zUpperBot, zUpperBot + t, decCarcass),
        // Крышка верхнего шкафа под потолком (z = zCeiling - 18 .. zCeiling) строго 0 .. depthCarcass
        frame.box(s0 + t, s1 - t, 0, depthCarcass, zCeiling - t, zCeiling, decCarcass),
        // Задняя стенка верхнего шкафа и внутренние полки (строго внутри корпуса!)
        frame.box(s0 + t, s1 - t, 0, 16, zUpperBot + t, zCeiling - t, decCarcass),
        frame.box(s0 + t, s1 - t, 16, depthCarcass - 2, Math.round((zUpperBot + zCeiling) * 0.5), Math.round((zUpperBot + zCeiling) * 0.5) + t, decCarcass),
      ];

      // Накладные дверцы верхнего шкафа (перекрывают полку zUpperBot..zUpperBot+t и боковины спереди на d = depthCarcass+2..depthCarcass+20, БЕЗ ручек!)
      const doorsRes = this.buildOverlayDoors(frame, s0, s1, depthCarcass, zUpperBot, zCeiling, decFacade || decCarcass, {
        doors: opts.doors || 2,
        milledStyle: opts.milledStyle || null,
        handleType: opts.handleType || 'none',
        decHandle: opts.decHandle,
      });

      return {
        carcassParts: carcassParts.filter(Boolean),
        facadeParts: doorsRes.facadeParts,
        handleParts: doorsRes.handleParts,
      };
    },

    /**
     * 10. ЭТАЛОННЫЙ УЗЕЛ: КОРОБ ИНСТАЛЛЯЦИИ УНИТАЗА + ВСТРОЕННЫЙ ШКАФ НАД НИМ ДО ПОТОЛКА
     *     Исключает ошибку, когда дно шкафчика над инсталляцией оказывается короче боковин, а фасады висят в воздухе или с короткими ручками!
     */
    buildOverToiletCabinet(frame, s0, s1, depthInstallBox, depthUpperCab, zInstallTop, zCeiling, decBox, decCarcass, decFacade, opts = {}) {
      const t = opts.thick || 18;
      const depthCarcass = depthUpperCab - 20; // 2 мм зазор + 18 мм накладной фасад = ровно depthUpperCab!

      // 1. Нижний зашивной короб инсталляции в плитке/керамограните (z = 0 .. zInstallTop, d = 0 .. depthInstallBox)
      const boxParts = [
        frame.box(s0, s1, 0, depthInstallBox, 0, zInstallTop, decBox),
      ].filter(Boolean);

      // 2. Корпус верхнего шкафа (z = zInstallTop .. zCeiling): боковины, дно, крышка и полки СТРОГО единой глубины depthCarcass!
      const carcassParts = [
        frame.box(s0, s0 + t, 0, depthCarcass, zInstallTop, zCeiling, decCarcass),
        frame.box(s1 - t, s1, 0, depthCarcass, zInstallTop, zCeiling, decCarcass),
        frame.box(s0 + t, s1 - t, 0, depthCarcass, zInstallTop, zInstallTop + t, decCarcass),
        frame.box(s0 + t, s1 - t, 0, depthCarcass, zCeiling - t, zCeiling, decCarcass),
        frame.box(s0 + t, s1 - t, 0, 16, zInstallTop + t, zCeiling - t, decCarcass),
        frame.box(s0 + t, s1 - t, 16, depthCarcass - 2, Math.round((zInstallTop + zCeiling) * 0.5), Math.round((zInstallTop + zCeiling) * 0.5) + t, decCarcass),
      ].filter(Boolean);

      // 3. Накладные фасады верхнего шкафа (d = depthCarcass + 2 .. depthCarcass + 20, СТРОГО БЕЗ РУЧЕК push-to-open!)
      const doorsRes = this.buildOverlayDoors(frame, s0, s1, depthCarcass, zInstallTop, zCeiling, decFacade || decCarcass, {
        doors: opts.doors || 2,
        milledStyle: opts.milledStyle || null,
        handleType: opts.handleType || 'none',
        decHandle: opts.decHandle,
      });

      return {
        boxParts,
        carcassParts,
        facadeParts: doorsRes.facadeParts,
        handleParts: doorsRes.handleParts,
      };
    },

    /**
     * 11. КАРТА ПАПОК «МОЙ КАБИНЕТ -> ИЗБРАННОЕ» ПОЛЬЗОВАТЕЛЯ ДЛЯ ЭТАПА 3 (РАССТАНОВКА МОДЕЛЕЙ И ДЕКОРА)
     *     Строгое соответствие папок и назначения комнат (чтобы агент НИКОГДА не ставил баночки санузла в гостиную или прихожую!).
     */
    FAVORITE_FOLDERS: {
      // Главный базовый декор (Прихожая консоль/полки, Гостиная тумба/столик/стеллаж, Спальня тумбочки/столик, Кабинет)
      shelfDecor: { fid: 28480394, name: 'Декор - Декор для полок', rooms: ['hall', 'kitchen_living', 'bedroom', 'office', 'teen'] },
      // Книги (Детская подростковая, Кабинет, книжные полки в гостиной; НЕ для спальни!)
      books: { fid: 28480289, name: 'Декор - Книги', rooms: ['teen', 'office', 'kids_school'] },
      // Букеты и озеленение (в первую очередь на ОБЕДЕННЫЕ СТОЛЫ, реже на журнальные столики)
      bouquets: { fid: 28480396, name: 'Растения - Букеты', rooms: ['dining_table', 'coffee_table'] },
      greenery: { fid: 28480397, name: 'Растения - Озеленение', rooms: ['dining_table', 'coffee_table'] },
      // Напольные зелёные растения и зелёные букеты («Растения - Растения» два раза — когда нужно поставить зелёное растение!)
      plantsFloor: { fid: 28480305, name: 'Растения - Растения', rooms: ['all_green_plants'] },
      // Кухня (стеклянные витрины кухни, открытые полки кухни, столешница кухни)
      kitchenDecor: { fid: 28480297, name: 'Кухня - Декор для кухни', rooms: ['kitchen'] },
      // Санузел и ванная (СТРОГО ТОЛЬКО для санузлов и ванных комнат!)
      bathDecor: { fid: 28480273, name: 'Санузел - Декор для санузла', rooms: ['bath', 'wc'] },
      bathSanitary: { fid: 28480274, name: 'Санузел - Сантехника', rooms: ['bath', 'wc'] },
      bathShower: { fid: 28480272, name: 'Санузел - Душевая', rooms: ['bath', 'wc'] },
      bathTowelWarmer: { fid: 28480387, name: 'Санузел - Полотенцесушители', rooms: ['bath', 'wc'] },
      bathVanity: { fid: 28480280, name: 'Санузел - Тумбы с раковинами', rooms: ['bath', 'wc'] },
      // Прачечная и хозкладовая (банки, хознужды, порошки, полотенца, бумага)
      laundry: { fid: 28480352, name: 'Прачечная - Наполнение прачечной', rooms: ['laundry', 'storage', 'wc_laundry'] },
      // Гардеробная и шкафы с одеждой/обувью (плечики, стопки одежды, сумки, обувь, коробки, чемоданы)
      wardrobe: { fid: 28480340, name: 'Гардероб - Одежда', rooms: ['wardrobe', 'hall_storage', 'dressing'] },
      // Детская для малышей (игрушки — ТОЛЬКО для малышей, НЕ для подростков!)
      kidsToddlers: { fid: 28480337, name: 'Детская комната - Детский', rooms: ['kids_toddler'] },
      // БАЗОВАЯ ПАПКА «по умолчанию» (fid: 28463658) — главные ходовые модели в КАЖДЫЙ проект (техника, сантехника, двери, ТВ, шторы, конвектор, кондиционер)
      defaultModels: { fid: 28463658, name: 'по умолчанию', rooms: ['all'] },
      // Дополнительные папки мебели, света и текстиля в Избранном
      rugs: { fid: 28480393, name: 'Декор - Ковры', rooms: ['all'] },
      curtains: { fid: 28480390, name: 'Декор - Шторы', rooms: ['all'] },
      pillowsThrows: { fid: 28480391, name: 'Декор - Пледы и подушка', rooms: ['all'] },
      mirrors: { fid: 28480287, name: 'Декор - Зеркала', rooms: ['all'] },
      wallDecor: { fid: 28480296, name: 'Декор - Декор стен', rooms: ['all'] },
      pendantLights: { fid: 28480398, name: 'Освещение - Подвесные светильники', rooms: ['all'] },
      wallSconces: { fid: 28480395, name: 'Освещение - Бра', rooms: ['all'] },
      floorLamps: { fid: 28480300, name: 'Освещение - Торшеры', rooms: ['all'] },
      tableLamps: { fid: 28480299, name: 'Освещение - Настольные светильники', rooms: ['all'] },
      chandeliers: { fid: 28480293, name: 'Освещение - Люстры', rooms: ['all'] },
    },

    /**
     * 11.1. СЛОВАРЬ БАЗОВЫХ МОДЕЛЕЙ ИЗ ПАПКИ «по умолчанию» (fid: 28463658), КОТОРЫЕ ИСПОЛЬЗУЮТСЯ В КАЖДОМ ПРОЕКТЕ В ПЕРВУЮ ОЧЕРЕДЬ!
     *       Агенту ЗАПРЕЩЕНО искать их заново в общем каталоге или моделировать вручную примитивами.
     *       Составные группы («Моя группа», productType: 'Assembly') можно ставить целиком или передавать { ungroup: true },
     *       либо брать отдельные под-модели по их прямым seekId ниже.
     */
    DEFAULT_PROJECT_MODELS: {
      // --- ДВЕРИ, КЛИМАТ, ТВ, ШТОРЫ (В КАЖДЫЙ ПРОЕКТ) ---
      entry_door: {
        seekId: '69de6309-139a-45c5-ae98-3e582394508d',
        name: 'дверь 2 (Входная дверь с глазком)',
        note: 'Ставить как входную дверь в каждом проекте, подгонять под размер входного проёма',
      },
      interior_door: {
        seekId: '11b3ed92-f962-42fd-81ba-5897dd6cf580',
        name: '55 2300 (Межкомнатная дверь скрытого монтажа / базовая)',
        note: 'Базовая межкомнатная дверь во все проёмы (можно включать/настраивать наличники и доборы)',
      },
      air_conditioner: {
        seekId: 'b4ff0a07-b6eb-4df7-a84c-a939894745ad',
        name: '6584047.66503ecc95634 (Настенный кондиционер)',
        note: 'Базовый внутренний блок кондиционера (837×200×313 мм)',
      },
      floor_convector: {
        seekId: 'bbf509c9-a2e3-48d7-af8b-cfea59ce3cf8',
        rawSeekId: 'f3dd1512-9392-4c31-8f96-f1c38e791f6f',
        name: 'к12Material Replace (Внутрипольный конвектор)',
        note: 'Внутрипольный конвектор (271×2970×5 мм) в пол перед панорамными окнами / выходом на балкон',
      },
      tv: {
        seekId: '50e133d0-cf25-44d5-96dd-e145af366bdb',
        rawSeekId: '37f6d20a-1f60-42e8-827a-027b989d354e',
        name: 'телевизор без розетокMaterial Replace (Базовый ТВ)',
        note: 'Единая базовая модель ТВ во все проекты (масштабировать под нужную диагональ, не рисовать вручную)',
      },
      curtain_tulle: {
        seekId: 'a3b71a1e-2cca-472c-aab3-c369eac176eb',
        rawSeekId: '3618913c-207a-4ba9-ad3a-c7f88f913b5c',
        name: 'Dawn 381 Curtain by KvadratMaterial Replace (Тюль)',
        note: 'Базовый тюль в пол (95×3120×2660 мм), подгоняется по ширине/высоте окна',
      },
      curtain_blackout: {
        seekId: 'ecaeff49-c16c-4da5-9c5d-7c95ea5a3437',
        name: 'шт2 (Прямые портьеры Blackout в пол)',
        note: 'Базовые шторы блэкаут (555×220×3175 мм), комбинируются с тюлем',
      },
      window_blinds: {
        seekId: '45108571-2fec-428a-9fd3-c46ffb51cb26',
        rawSeekId: '4911dfaf-ac65-45ad-a56d-2b3f0810a05b',
        name: 'Minimalist Solid Wood Window Blinds 3D ModelMaterial Replace (Жалюзи)',
        note: 'Горизонтальные жалюзи на окна',
      },

      // --- КУХНЯ (В КАЖДЫЙ ПРОЕКТ) ---
      cooktop: {
        seekId: '6e7e5a66-072b-4d01-b287-3f5d8a1b6c08',
        name: 'Set_Asko 1 (Варочная поверхность сенсорная)',
        note: 'Базовая индукционная/сенсорная варочная панель 560×490×7 мм на столешницу кухни',
      },
      oven_microwave: {
        seekId: '51295004-e3e0-4bba-819c-6efd45ab4481',
        name: 'духовка и свч (Встраиваемая пара духовка + СВЧ)',
        note: 'Готовый блок духовка + СВЧ (596×608×982 мм) для встраивания в пенал кухни 600 мм',
      },
      kitchen_sink_set: {
        seekId: '1dd3d8b6-a3cf-43a9-a243-3e7782fb5da1',
        name: 'Моя группа: Кухонная раковина (мойка) + смеситель',
        subIds: {
          sink: '3b14a132-13a5-4bb3-8d00-7ea9f472bb98',
          faucet: '661ed024-e924-491a-a416-dd223ba14f6e',
        },
        note: 'Можно разгруппировать (ungroup: true) и подогнать мойку (3b14a132...) под индивидуальный вырез столешницы',
      },
      kitchen_sink_only: {
        seekId: '3b14a132-13a5-4bb3-8d00-7ea9f472bb98',
        name: 'д 24 (Чаша кухонной мойки отдельно)',
        note: 'Отдельно чаша мойки для точной подгонки под вырез в столешнице',
      },
      kitchen_faucet: {
        seekId: '5af1f675-87d3-4878-a313-f096187915fe',
        rawSeekId: 'e0ba1c05-72a0-4f0e-a455-07fba948b4a4',
        name: 'смесительMaterial Replace (Кухонный смеситель отдельно)',
        note: 'Отдельный кухонный смеситель без мойки',
      },

      // --- САНУЗЕЛ И ПОСТИРОЧНАЯ (В КАЖДЫЙ ПРОЕКТ) ---
      bath_vessel_sink_set: {
        seekId: '72eaee08-4ba9-41ea-9465-1f3e45dfe043',
        name: 'Моя группа: Раковина накладная + смеситель встроенный в стену',
        subIds: {
          sink: '5ef4c12b-926e-480f-b31c-77ee2b36f181',
          wallFaucet: 'd008f99d-011b-425f-a157-d6522a6e1250',
        },
        note: 'Если в проекте другой смеситель (накладной), разгруппировать (ungroup: true) или взять отдельно bath_vessel_sink_only',
      },
      bath_vessel_sink_only: {
        seekId: '5ef4c12b-926e-480f-b31c-77ee2b36f181',
        name: 'раковина 3 (Накладная чаша раковины в санузел отдельно)',
        note: 'Отдельно накладная раковина без встроенного в стену смесителя',
      },
      bath_wall_faucet_only: {
        seekId: 'd008f99d-011b-425f-a157-d6522a6e1250',
        name: 'сант3 (Смеситель раковины встроенный в стену отдельно)',
        note: 'Отдельно настенный смеситель для раковины',
      },
      shower_set_with_water: {
        seekId: '1a60f73b-c4df-40b9-a3f0-839e290e7085',
        name: 'Моя группа: Душевая стойка со встроенным смесителем и струями воды',
        subIds: {
          mixerAndTopShower: '365afa86-aa4f-48ef-a7d7-176022b2f506',
          waterEffect: '29ea952b-7fa5-481a-9e69-9ab6c3a861e3',
          handShower: '72abd017-c0a2-44e9-8cc6-52a901efb3bd',
        },
        note: 'Готовый душевой комплект сразу со струями воды (534×348×2379 мм), при необходимости разгруппировывается',
      },
      toilet_full_set: {
        seekId: 'd3307a4c-558d-4b6f-94ab-1ae898366e03',
        name: 'Моя группа: Подвесной унитаз + кнопка смыва + гигиенический душ + туалетная бумага + ёршик',
        subIds: {
          toilet: '998b042f-5227-4a99-9656-786d5d3e0b16',
          flushButton: '4d947867-709d-4b2e-9374-4d1b83b76a0d',
          hygienicShower: '4c397679-5838-4813-9c63-417412e778b1',
          toiletPaper: '9b83f701-d89f-492c-ad13-04a515a9f774',
          toiletBrush: 'f7894ec6-3e62-4337-9681-049d2f35d269',
        },
        note: 'Полный комплект узла инсталляции унитаза (можно разгруппировать через ungroup: true и передвинуть кнопку/гиг. душ/ёршик по месту)',
      },
      washing_machine: {
        seekId: '5e1c20f9-4c90-405b-9223-bcdc02d8377d',
        name: 'Washing Machine Series 8 2024 by Bosh (Стиральная машина)',
        note: 'Базовая стиральная машина 598×665×853 мм',
      },
      tumble_dryer: {
        seekId: 'e73f998c-0007-4bca-bb77-25bcdb40e73c',
        name: 'Heat Pump Tumble Dryer Series 8 2024 by Bosch (Сушильная машина)',
        note: 'Базовая сушильная машина 599×641×857 мм (в колонну или рядом со стиралкой)',
      },
    },

    /**
     * 11.2. ЖИВОЕ ЧТЕНИЕ ВСЕХ МОДЕЛЕЙ ИЗ ПАПКИ «по умолчанию» (fid: 28463658)
     *       На случай, если пользователь добавила туда новые базовые модели.
     */
    async getDefaultFolderModels() {
      const win = getTargetWindow();
      const res = await win.NWTK.mtop.Catalog.getFavProducts({
        data: { favoritesId: 28463658, offset: 0, limit: 60 }
      });
      const data = res?.data?.result || res?.data || {};
      return (data.items || []).map(it => ({
        seekId: it.id || it.seekId,
        name: it.name,
        productType: it.productType,
        image: it.image,
      }));
    },

    /**
     * 12. РАНДОМИЗИРОВАННАЯ ВЫБОРКА МОДЕЛЕЙ ИЗ ПАПКИ «МОЙ КАБИНЕТ -> ИЗБРАННОЕ» (ВРАЗНОБОЙ, А НЕ ПЕРВЫЕ МОДЕЛИ!)
     *     Автоматически считывает актуальное количество моделей в папке (включая новые добавленные пользователем)
     *     и возвращает перемешанную выборку со случайным смещением offset, чтобы из проекта в проект не повторялись одни и те же первые модели.
     */
    async sampleFavoriteModels(folderKeyOrNameOrFid, count = 12, opts = {}) {
      const win = getTargetWindow();
      const app = win.HSApp?.App?.getApp();
      const favPlugin = app?.pluginManager?.getPlugin('hsw.plugin.favorite.Plugin');
      const liveGroups = favPlugin?.getStore?.()?.getState?.()?.groupItems || [];

      let targetFid = null;
      let targetName = '';

      if (typeof folderKeyOrNameOrFid === 'number') {
        targetFid = folderKeyOrNameOrFid;
      } else if (typeof folderKeyOrNameOrFid === 'string') {
        const preset = this.FAVORITE_FOLDERS[folderKeyOrNameOrFid];
        if (preset) {
          targetFid = preset.fid;
          targetName = preset.name;
        } else {
          const q = folderKeyOrNameOrFid.trim().toLowerCase();
          const byPreset = Object.values(this.FAVORITE_FOLDERS).find(f => f.name.toLowerCase() === q || f.name.toLowerCase().includes(q));
          if (byPreset) {
            targetFid = byPreset.fid;
            targetName = byPreset.name;
          }
        }
      }

      const liveMatch = liveGroups.find(g =>
        (targetFid && Number(g.fid) === Number(targetFid)) ||
        (typeof folderKeyOrNameOrFid === 'string' && g.name && g.name.toLowerCase().includes(folderKeyOrNameOrFid.trim().toLowerCase()))
      );
      if (liveMatch) {
        targetFid = liveMatch.fid;
        targetName = liveMatch.name;
      }

      if (!targetFid) {
        throw new Error(`Папка Избранного не найдена: ${folderKeyOrNameOrFid}`);
      }

      // Сначала узнаём общий размер папки (total), чтобы брать модели ВРАЗНОБОЙ со всей глубины папки
      const probeRes = await win.NWTK.mtop.Catalog.getFavProducts({
        data: { favoritesId: targetFid, offset: 0, limit: 40 }
      });
      const probeData = probeRes?.data?.result || probeRes?.data || {};
      const total = Number(probeData.total || (probeData.items && probeData.items.length) || 0);
      let pool = Array.isArray(probeData.items) ? [...probeData.items] : [];

      if (total > 40 && opts.randomOffset !== false) {
        const maxOffset = Math.max(0, total - 40);
        const randOffset = opts.offset !== undefined
          ? opts.offset
          : Math.floor(Math.random() * (maxOffset + 1));
        if (randOffset > 0) {
          const pageRes = await win.NWTK.mtop.Catalog.getFavProducts({
            data: { favoritesId: targetFid, offset: randOffset, limit: 45 }
          });
          const pageData = pageRes?.data?.result || pageRes?.data || {};
          if (Array.isArray(pageData.items) && pageData.items.length > 0) {
            pool = pool.concat(pageData.items);
          }
        }
      }

      // Убираем дубликаты и перемешиваем (Fisher-Yates shuffle) для разнообразия из проекта в проект
      const seen = new Set();
      const unique = [];
      for (const it of pool) {
        const sid = it?.id || it?.seekId;
        if (sid && !seen.has(sid)) {
          seen.add(sid);
          unique.push({
            seekId: sid,
            name: it.name || '',
            image: it.image || it.thumbnail || '',
          });
        }
      }
      if (opts.shuffle !== false) {
        for (let i = unique.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          const tmp = unique[i];
          unique[i] = unique[j];
          unique[j] = tmp;
        }
      }

      return {
        fid: targetFid,
        folderName: targetName,
        totalInFolder: total,
        items: unique.slice(0, count),
      };
    },

    /**
     * 13. МАТЕМАТИЧЕСКИЙ РАСЧЁТ УГЛА ПОВОРОТА МОДЕЛИ СТРОГО ЛИЦОМ ВПЕРЁД В КОМНАТУ (ZRotation / rotation)
     *     В Homestyler лицевая сторона 3D-модели при rotation = 0 смотрит в сторону (0, -1) (на Юг).
     *     При повороте по часовой стрелке на угол rot вектор лица равен (-sin(rot), -cos(rot)).
     *     Чтобы модель на полке/консоли/стене смотрела строго ЛИЦОМ ВПЕРЁД по нормали стены (frame.nx, frame.ny):
     *     rotation = atan2(-nx, -ny) * 180 / PI + extraOffsetDeg.
     */
    calcForwardRotation(frameOrNormal, extraOffsetDeg = 0) {
      const nx = frameOrNormal?.nx !== undefined ? frameOrNormal.nx : 0;
      const ny = frameOrNormal?.ny !== undefined ? frameOrNormal.ny : -1;
      const baseDeg = Math.atan2(-nx, -ny) * (180 / Math.PI);
      return ((baseDeg + (extraOffsetDeg || 0)) % 360 + 360) % 360;
    },

    /**
     * 14. РАЗМЕЩЕНИЕ МОДЕЛИ ИЗ «ИЗБРАННОГО» (ИЛИ ИЗ «по умолчанию» ПО КЛЮЧУ) НА ПОЛКУ / КОНСОЛЬ / ТУМБУ / ПОЛ СТРОГО ЛИЦОМ ВПЕРЁД
     *     Поддерживает:
     *     - seekId напрямую ИЛИ короткий ключ из HSJoinery.DEFAULT_PROJECT_MODELS (например: 'cooktop', 'oven_microwave', 'kitchen_sink_set',
     *       'tv', 'air_conditioner', 'entry_door', 'interior_door', 'curtain_tulle', 'curtain_blackout', 'floor_convector',
     *       'bath_vessel_sink_set', 'bath_vessel_sink_only', 'shower_set_with_water', 'toilet_full_set', 'washing_machine', 'tumble_dryer')
     *     - как одиночные 3D-модели (productType: '3D'), так и составные группы / Material Replace (productType: 'Assembly', «Моя группа»)
     *     - опцию { ungroup: true } для автоматической разгруппировки составных групп («Моя группа»), чтобы подогнать раковину/смеситель/кнопку по месту
     *     - привязку к стеновому фрейму frame в миллиметрах: { frame, sMm, dMm, zMm, rotOffsetDeg }
     *     - или мировые координаты в метрах: { x, y, z, rotation }
     *     - опциональную подгонку габаритов в мм: { widthMm, depthMm, heightMm, uniformScale }.
     */
    async placeFavoriteModel(seekIdOrDefaultKey, opts = {}) {
      const win = getTargetWindow();
      const app = win.HSApp?.App?.getApp();
      const HSCore = win.HSCore;
      if (!app || !HSCore) throw new Error('HSApp / HSCore не найдены');

      const preset = this.DEFAULT_PROJECT_MODELS && this.DEFAULT_PROJECT_MODELS[seekIdOrDefaultKey];
      const seekId = preset ? (opts.useRaw3D && preset.rawSeekId ? preset.rawSeekId : preset.seekId) : seekIdOrDefaultKey;

      const prodMeta = await app.catalogManager.getProductBySeekId(seekId);
      if (!prodMeta) throw new Error(`Не удалось загрузить метаданные модели seekId=${seekId}`);

      let xM = opts.x || 0;
      let yM = opts.y || 0;
      let zM = opts.z !== undefined ? opts.z : ((opts.zMm || 0) / 1000);
      let rotDeg = opts.rotation !== undefined ? opts.rotation : 0;

      if (opts.frame) {
        const ptMm = opts.frame.pt(opts.sMm || 0, opts.dMm || 0);
        xM = ptMm.x / 1000;
        yM = ptMm.y / 1000;
        if (opts.rotation === undefined) {
          rotDeg = this.calcForwardRotation(opts.frame, opts.rotOffsetDeg || 0);
        }
      }

      let targetFloor = opts.host || null;
      if (!targetFloor) {
        app.floorplan?.scene?.activeLayer?.forEachFloor?.(fl => {
          if (!targetFloor) targetFloor = fl;
        });
      }

      let content = null;
      let members = [];

      const isAssembly =
        prodMeta.productType === 'Assembly' ||
        (win.HSCatalog?.ProductTypeEnum?.Assembly && prodMeta.productType === win.HSCatalog.ProductTypeEnum.Assembly);

      if (isAssembly && app.transManager && win.HSFPConstants?.RequestType?.AddProduct) {
        const req = app.transManager.createRequest(win.HSFPConstants.RequestType.AddProduct, [
          prodMeta,
          { x: xM, y: yM, z: zM },
          rotDeg,
          null,
          targetFloor,
        ]);
        content = app.transManager.commit(req);
        if (content) {
          content.x = xM;
          content.y = yM;
          content.z = zM;
          content.ZRotation = rotDeg;
          if (Array.isArray(content.members)) {
            members = [...content.members];
          }
          if (opts.ungroup && Array.isArray(content.members) && content.members.length > 0 && win.HSFPConstants?.RequestType?.UngroupContents) {
            const ungrpReq = app.transManager.createRequest(win.HSFPConstants.RequestType.UngroupContents, [content]);
            app.transManager.commit(ungrpReq);
          }
        }
      } else {
        content = HSCore.Model.Content.create(prodMeta);
        content.x = xM;
        content.y = yM;
        content.z = zM;
        content.XRotation = opts.XRotation || 0;
        content.YRotation = opts.YRotation || 0;
        content.ZRotation = rotDeg;
        HSCore.Util.Content.addContent({
          content,
          host: targetFloor,
          parent: app.floorplan.scene.activeLayer,
        });
      }

      if (content) {
        if (opts.uniformScale) {
          content.XScale = opts.uniformScale;
          content.YScale = opts.uniformScale;
          content.ZScale = opts.uniformScale;
        } else {
          if (opts.widthMm && prodMeta.XLength > 0) content.XScale = (opts.widthMm / 1000) / prodMeta.XLength;
          if (opts.depthMm && prodMeta.YLength > 0) content.YScale = (opts.depthMm / 1000) / prodMeta.YLength;
          if (opts.heightMm && prodMeta.ZLength > 0) content.ZScale = (opts.heightMm / 1000) / prodMeta.ZLength;
        }
        try {
          content.dirtyGeometry?.();
          content.refreshBoundInternal?.();
        } catch (e) {}
      }

      return {
        content,
        members,
        seekId,
        defaultKey: preset ? seekIdOrDefaultKey : null,
        name: prodMeta.name,
        productType: prodMeta.productType,
        x: xM,
        y: yM,
        z: zM,
        ZRotation: rotDeg,
        sizeMm: {
          w: Math.round((prodMeta.XLength || 0) * ((content && content.XScale) || 1) * 1000),
          d: Math.round((prodMeta.YLength || 0) * ((content && content.YScale) || 1) * 1000),
          h: Math.round((prodMeta.ZLength || 0) * ((content && content.ZScale) || 1) * 1000),
        },
      };
    },
  };

  const targetWin = getTargetWindow();
  targetWin.HSJoinery = Engine;
  targetWin.HSJoineryEngine = Engine;
  targetWin.HSDesignerHandles = Handles;
  window.HSJoinery = Engine;
  window.HSJoineryEngine = Engine;
  window.HSDesignerHandles = Handles;
})();
