/**
 * Эталонная математическая библиотека контуров современных дизайнерских врезных/интегрированных ручек
 * для Homestyler (webCADDocument / CustomizedPMModel) и Blender.
 *
 * ЖЕЛЕЗНЫЕ ПРАВИЛА КОНСТРУКТИВА (ПОЧЕМУ РАНЬШЕ ПОЛУЧАЛОСЬ ПЛОХО И КАК СТРОИТЬ ИДЕАЛЬНО):
 * 1. НИКОГДА не режь фасад на 2-4 прямоугольника вокруг ручки! В Homestyler каждый стык даёт чёрную линию-шов.
 *    Фасад с любой торцевой или угловой выборкой ВСЕГДА строится ОДНИМ замкнутым многоугольником (pts),
 *    и выдавливается на толщину фасада (18-20 мм) единым телом без единого шва!
 * 2. Врезная ручка — это ВСЕГДА РЕАЛЬНАЯ ГЛУБИНА (выемка вглубь на 12-15 мм от лицевой плоскости фасада),
 *    а НЕ плоская палка, наклеенная поверх фасада или заподлицо с ним!
 * 3. За вырезом в фасаде ОБЯЗАТЕЛЬНО ставится утопленная на 12-14 мм вглубь «Подложка ручки / Внутренний профиль»
 *    (отдельная группа DiyInstance «Ручки / Вставки», толщина 6-8 мм, утоплена относительно лица фасада на 12 мм),
 *    чтобы внутри выемки падала реальная объёмная тень и она перекрашивалась в 1 клик (в шпон дерева, графит, латунь или в цвет фасада).
 * 4. Все переходы на вырезах делаются ТОЛЬКО через плавный скос 45° (chamfer = ширина выреза) или гладкую дугу из 10-16 точек (Math.sin/cos).
 */

window.HSDesignerHandles = {
  /**
   * ТИП 1 (Фото 1 и Фото 4): Фасад с боковой торцевой выемкой со скосами 45° (трапециевидный вырез на торце).
   * Подходит для: локальных торцевых ручек (высота 180-300 мм) И для вертикальных щелевых ручек во всю высоту со скосом (Фото 4).
   *
   * @param {number} W - ширина фасада (мм), напр. 450
   * @param {number} H - высота фасада (мм), напр. 2400
   * @param {'left'|'right'} side - на каком вертикальном торце вырез ('left' при x=0 или 'right' при x=W)
   * @param {number} yBottom - нижняя точка прямого участка выемки от низа фасада (мм), напр. 900 (или 0, если идёт от самого низа как на Фото 4)
   * @param {number} yTop - верхняя точка прямого участка выемки от низа фасада (мм), напр. 1150 (или H, если уходит до верха)
   * @param {number} cutWidth - ширина выборки по горизонтали (мм), стандарт 18-22 мм
   * @param {number} chamfer - высота плавного скоса 45° сверху/снизу (мм), стандарт = cutWidth (18-22 мм) или 35-45 мм для мягкого скоса (Фото 4)
   * @returns {Array<{x:number, y:number}>} единый замкнутый полигон фасада без швов
   */
  buildFacadeWithChamferSlot(W, H, side = 'right', yBottom = 950, yTop = 1170, cutWidth = 20, chamfer = 22) {
    const c = Math.max(cutWidth, chamfer);
    if (side === 'right') {
      const pts = [
        { x: 0, y: 0 },
        { x: 0, y: H },
      ];
      if (yTop >= H - 1) {
        pts.push({ x: W - cutWidth, y: H });
      } else {
        pts.push({ x: W, y: H });
        pts.push({ x: W, y: Math.min(H, yTop + c) });
        pts.push({ x: W - cutWidth, y: yTop });
      }
      if (yBottom <= 1) {
        pts.push({ x: W - cutWidth, y: 0 });
      } else {
        pts.push({ x: W - cutWidth, y: yBottom });
        pts.push({ x: W, y: Math.max(0, yBottom - c) });
        pts.push({ x: W, y: 0 });
      }
      return pts;
    } else {
      const pts = [];
      if (yBottom <= 1) {
        pts.push({ x: cutWidth, y: 0 });
      } else {
        pts.push({ x: 0, y: 0 });
        pts.push({ x: 0, y: Math.max(0, yBottom - c) });
        pts.push({ x: cutWidth, y: yBottom });
      }
      if (yTop >= H - 1) {
        pts.push({ x: cutWidth, y: H });
      } else {
        pts.push({ x: cutWidth, y: yTop });
        pts.push({ x: 0, y: Math.min(H, yTop + c) });
        pts.push({ x: 0, y: H });
      }
      pts.push({ x: W, y: H });
      pts.push({ x: W, y: 0 });
      return pts;
    }
  },

  /**
   * ТИП 2 (Фото 1): Фасад с полукруглой ИЛИ вертикальной капсульной («таблетка») торцевой выемкой.
   * На одной створке даёт полукруг, а на двух соседних створках образует идеальный круг или вертикальную капсулу!
   *
   * @param {number} W - ширина фасада (мм)
   * @param {number} H - высота фасада (мм)
   * @param {'left'|'right'} side - торец выреза
   * @param {number} yCenter - высота центра ручки от низа фасада (мм), напр. 1050
   * @param {number} radius - глубина радиуса на 1 створке (мм): для круга 65-80 мм, для узкой капсулы 18-22 мм
   * @param {number} straightHeight - длина прямой вставки между верхним и нижним полукругом (0 = чистый круг/полукруг, 140-180 = капсула)
   * @param {number} arcSegments - число сегментов дуги (минимум 16 для идеальной гладкости)
   */
  buildFacadeWithArcOrCapsuleSlot(W, H, side = 'right', yCenter = 1050, radius = 70, straightHeight = 0, arcSegments = 16) {
    const halfStraight = straightHeight / 2;
    const yTopArcCenter = yCenter + halfStraight;
    const yBotArcCenter = yCenter - halfStraight;

    if (side === 'right') {
      const pts = [
        { x: 0, y: 0 },
        { x: 0, y: H },
        { x: W, y: H },
      ];
      // Верхняя четверть дуги: от угла +90° (x=W, y=yTopArcCenter+R) до 180° (x=W-R, y=yTopArcCenter)
      for (let i = 0; i <= arcSegments; i++) {
        const t = (Math.PI / 2) * (i / arcSegments); // 0 -> PI/2
        pts.push({
          x: W - radius * Math.sin(t),
          y: yTopArcCenter + radius * Math.cos(t),
        });
      }
      // Нижняя четверть дуги: от (x=W-R, y=yBotArcCenter) до (x=W, y=yBotArcCenter-R)
      for (let i = 0; i <= arcSegments; i++) {
        const t = (Math.PI / 2) * (i / arcSegments); // 0 -> PI/2
        pts.push({
          x: W - radius * Math.cos(t),
          y: yBotArcCenter - radius * Math.sin(t),
        });
      }
      pts.push({ x: W, y: 0 });
      return pts;
    } else {
      const pts = [{ x: 0, y: 0 }];
      // Нижняя четверть дуги на левом торце
      for (let i = 0; i <= arcSegments; i++) {
        const t = (Math.PI / 2) * (i / arcSegments);
        pts.push({
          x: radius * Math.sin(t),
          y: yBotArcCenter - radius * Math.cos(t),
        });
      }
      // Верхняя четверть дуги на левом торце
      for (let i = 0; i <= arcSegments; i++) {
        const t = (Math.PI / 2) * (i / arcSegments);
        pts.push({
          x: radius * Math.cos(t),
          y: yTopArcCenter + radius * Math.sin(t),
        });
      }
      pts.push({ x: 0, y: H });
      pts.push({ x: W, y: H });
      pts.push({ x: W, y: 0 });
      return pts;
    }
  },

  /**
   * ТИП 3 (Фото 5): Горизонтальная капсульная выемка на нижнем (или верхнем) краю фасада со скруглёнными углами,
   * за которой ставится утопленная шпонированная деревянная планка с горизонтальной фрезеровкой.
   *
   * @param {number} W - ширина фасада (мм), напр. 500
   * @param {number} H - высота верхнего фасада (мм), напр. 1550
   * @param {'bottom_left'|'bottom_right'|'bottom_center'} position - где на нижнем торце расположена полукапсула
   * @param {number} slotLength - длина выемки на этой створке (мм), напр. 200-220 мм (на две створки даёт капсулу 400-440 мм)
   * @param {number} slotHeight - высота выемки (мм), стандарт 38-45 мм
   * @param {number} cornerRadius - радиус скругления внешнего края капсулы (мм), стандарт = slotHeight * 0.65 (25-30 мм)
   */
  buildFacadeWithHorizontalCapsule(W, H, position = 'bottom_right', slotLength = 210, slotHeight = 42, cornerRadius = 26, segs = 10) {
    const r = Math.min(cornerRadius, slotHeight - 2, slotLength / 2);
    const pts = [
      { x: 0, y: H },
      { x: W, y: H },
    ];

    if (position === 'bottom_right') {
      // Выемка примыкает к правому нижнему углу (стыку с правой створкой)
      const xStart = W - slotLength;
      pts.push({ x: W, y: slotHeight });
      pts.push({ x: xStart + r, y: slotHeight });
      // Плавная четверть дуги от (xStart+r, slotHeight) вниз к (xStart, slotHeight-r) и до (xStart, 0)
      for (let i = 1; i <= segs; i++) {
        const t = (Math.PI / 2) * (i / segs);
        pts.push({
          x: (xStart + r) - r * Math.sin(t),
          y: (slotHeight - r) + r * Math.cos(t),
        });
      }
      pts.push({ x: xStart, y: 0 });
      pts.push({ x: 0, y: 0 });
    } else if (position === 'bottom_left') {
      // Выемка примыкает к левому нижнему углу (стыку с левой створкой)
      const xEnd = slotLength;
      pts.push({ x: W, y: 0 });
      pts.push({ x: xEnd, y: 0 });
      for (let i = 0; i <= segs; i++) {
        const t = (Math.PI / 2) * (i / segs);
        pts.push({
          x: (xEnd - r) + r * Math.cos(t),
          y: (slotHeight - r) + r * Math.sin(t),
        });
      }
      pts.push({ x: 0, y: slotHeight });
    }
    return pts;
  },

  /**
   * ТИП 4 и 5 (Фото 2 и Фото 3): Поперечное сечение (профиль для выдавливания вдоль фасада)
   * для С-образного профиля с рамкой (Фото 2) и J-скоса 45° / Gola (Фото 3).
   */
  profiles: {
    /**
     * Сечение С-образного врезного профиля (Фото 2):
     * Наружная высота 40 мм, глубина 18 мм, толщина верхней/нижней полки-рамки 3 мм, глубина паза под пальцы 14 мм.
     */
    cChannelSection(height = 40, depth = 18, rimThickness = 3.5, grooveDepth = 14) {
      return [
        { x: 0, y: 0 },
        { x: depth, y: 0 },
        { x: depth, y: rimThickness },
        { x: depth - grooveDepth, y: rimThickness },
        { x: depth - grooveDepth, y: height - rimThickness },
        { x: depth, y: height - rimThickness },
        { x: depth, y: height },
        { x: 0, y: height },
      ];
    },

    /**
     * Сечение фасада со скошенным под 45° верхним торцом (J-профиль / скос 45°, Фото 3):
     * Лицевая сторона имеет тонкую кромку 2.5 мм, а внутрь к корпусу идёт скос 45° на глубину 15.5 мм.
     */
    bevel45FacadeSection(facadeHeight = 720, thickness = 18, frontLip = 2.5) {
      const bevel = thickness - frontLip;
      return [
        { x: 0, y: 0 },                       // задний нижний угол
        { x: thickness, y: 0 },               // лицевой нижний угол
        { x: thickness, y: facadeHeight },    // лицевой верхний угол (самая высокая точка)
        { x: thickness - frontLip, y: facadeHeight }, // тонкая передняя кромка 2.5 мм
        { x: 0, y: facadeHeight - bevel },    // скос 45° вниз-вглубь к задней стенке фасада
      ];
    },
  },
};
