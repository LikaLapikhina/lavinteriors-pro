(() => {
  let autoRestoreCheckedForScene = false;

  const resolveAndLoadPanel = async (btn) => {
    if (btn) btn.textContent = '⏳ Загрузка...';
    // 1. Try local server (PC or local laptop server)
    try {
      const ctrl = new AbortController();
      const tid = setTimeout(() => ctrl.abort(), 1400);
      const res = await fetch('http://127.0.0.1:3033/homestyler-panel.js?t=' + Date.now(), { signal: ctrl.signal });
      clearTimeout(tid);
      if (res.ok) {
        const code = await res.text();
        if (btn) btn.remove();
        window.__SKYPRO_SERVER_ORIGIN__ = 'http://127.0.0.1:3033';
        (0, eval)(code);
        return true;
      }
    } catch (e) {}

    // 2. Fallback to Cloud Tunnel published at lavinteriors.pro/office/skypro-endpoint.json
    try {
      const epRes = await fetch('https://lavinteriors.pro/office/skypro-endpoint.json?t=' + Date.now());
      if (epRes.ok) {
        const ep = await epRes.json();
        const origin = String(ep.tunnelUrl || '').replace(/\/+$/, '');
        if (origin) {
          window.__SKYPRO_SERVER_ORIGIN__ = origin;
          const res2 = await fetch(origin + '/homestyler-panel.js?t=' + Date.now());
          if (res2.ok) {
            const code2 = await res2.text();
            if (btn) btn.remove();
            (0, eval)(code2);
            return true;
          }
        }
      }
    } catch (e2) {}

    if (btn) {
      btn.textContent = '⚡ 3DSky Панель';
      alert('Не удалось подключиться к серверу 3DSky Pro (ни локально 127.0.0.1:3033, ни через облачный туннель). Проверьте, что на главном ПК запущен SkyPro Start!');
    }
    return false;
  };

  const checkAndMountLauncher = () => {
    if (!window.HSApp || !window.HSApp.App) return;
    const app = window.HSApp.App.getApp && window.HSApp.App.getApp();

    if (app && app.floorplan && !autoRestoreCheckedForScene) {
      let hasContents = false;
      let hasSkyProPlaceholder = false;
      app.floorplan.forEachContent(c => {
        hasContents = true;
        const mName = String((c.metadata && c.metadata.name) || '').trim();
        const dName = String(c.displayName || '').trim();
        if (dName && mName && dName !== mName) {
          hasSkyProPlaceholder = true;
        }
      });
      if (hasContents) {
        autoRestoreCheckedForScene = true;
        if (hasSkyProPlaceholder && !document.getElementById('skypro-hs-right-panel')) {
          resolveAndLoadPanel(document.getElementById('skypro-hs-launcher-pill'));
          return;
        }
      }
    }

    if (document.getElementById('skypro-hs-toggle-btn') || document.getElementById('skypro-hs-launcher-pill')) return;

    const btn = document.createElement('button');
    btn.id = 'skypro-hs-launcher-pill';
    btn.textContent = '⚡ 3DSky Панель';
    btn.title = 'Нажмите, чтобы открыть панель 3DSky Pro + Спецматериалы';
    btn.style.cssText = [
      'position:fixed',
      'top:130px',
      'right:0px',
      'z-index:10000',
      'background:#2563eb',
      'color:#ffffff',
      'border:none',
      'border-radius:8px 0 0 8px',
      'padding:10px 6px',
      'writing-mode:vertical-rl',
      'font-size:11px',
      'font-weight:700',
      'cursor:pointer',
      'box-shadow:-2px 2px 10px rgba(37,99,235,0.32)',
      'font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif'
    ].join(';');

    btn.onclick = () => resolveAndLoadPanel(btn);
    document.body.appendChild(btn);
  };

  setInterval(checkAndMountLauncher, 2500);
})();
