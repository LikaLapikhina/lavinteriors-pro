chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: async () => {
        try {
          const ctrl = new AbortController();
          const tid = setTimeout(() => ctrl.abort(), 1400);
          const r = await fetch("http://127.0.0.1:3033/homestyler-panel.js?t=" + Date.now(), { signal: ctrl.signal });
          clearTimeout(tid);
          if (r.ok) {
            window.__SKYPRO_SERVER_ORIGIN__ = "http://127.0.0.1:3033";
            const c = await r.text();
            (0, eval)(c);
            return;
          }
        } catch (e) {}
        try {
          const epRes = await fetch("https://lavinteriors.pro/office/skypro-endpoint.json?t=" + Date.now());
          if (epRes.ok) {
            const ep = await epRes.json();
            const origin = String(ep.tunnelUrl || "").replace(/\/+$/, "");
            if (origin) {
              window.__SKYPRO_SERVER_ORIGIN__ = origin;
              const r2 = await fetch(origin + "/homestyler-panel.js?t=" + Date.now());
              if (r2.ok) {
                const c2 = await r2.text();
                (0, eval)(c2);
                return;
              }
            }
          }
        } catch (e2) {}
      }
    });
  } catch (err) {
    console.error("Failed to inject 3DSky Pro panel:", err);
  }
});
